"""Browser entry points for Empire Online A11y.

This module runs inside Pyodide (Python compiled to WebAssembly) in a Web Worker.
It mirrors the scan logic in ``brightspace_a11y_checker.ui`` but returns JSON and
report HTML to JavaScript instead of writing files and opening Tkinter dialogs.
Uploaded exports are mounted at a path in the in-browser filesystem and never
leave the user's computer.
"""

from __future__ import annotations

from datetime import datetime
import json
from pathlib import Path
import shutil
import tempfile

from brightspace_a11y_checker import __version__, cartridge
from brightspace_a11y_checker.cartridge import CartridgeError, course_id_from_export_name, course_id_from_url_or_text
from brightspace_a11y_checker.checklist import CHECKLIST_ITEMS
from brightspace_a11y_checker.models import Finding, SearchRecord
from brightspace_a11y_checker.quick_check import scan_pasted_html
from brightspace_a11y_checker.quiz_library import load_quiz_library
from brightspace_a11y_checker.report import write_html_report
from brightspace_a11y_checker.scanner import scan_combined_exports


WORK_ROOT = Path("/tmp/a11y")


def _extracted_cartridge_init(self: cartridge.ExtractedCartridge, source: Path) -> None:
    # The desktop app extracts next to the source file. Uploaded files may be mounted
    # read-only in the browser, so extract into a writable temp directory instead.
    WORK_ROOT.mkdir(parents=True, exist_ok=True)
    self.source = source
    self.temp_dir = Path(tempfile.mkdtemp(prefix=".a11y_", dir=WORK_ROOT))
    self.skipped_members = []


cartridge.ExtractedCartridge.__init__ = _extracted_cartridge_init


def app_info() -> str:
    return json.dumps({"version": __version__, "checklist": CHECKLIST_ITEMS})


def detect_course_id(filename: str) -> str:
    return course_id_from_export_name(Path(filename))


def run_scan(
    primary_path: str,
    module_intro_path: str = "",
    course_id_or_url: str = "",
    skip_hidden: bool = True,
    custom_terms_raw: str = "",
    include_file_inventory: bool = False,
    file_inventory_only: bool = False,
) -> str:
    source = Path(primary_path)
    module_intro_source = Path(module_intro_path) if module_intro_path else None
    file_inventory_only = include_file_inventory and file_inventory_only
    course_id = course_id_from_url_or_text(course_id_or_url) or course_id_from_export_name(source)
    try:
        findings, search_records = scan_combined_exports(
            source,
            module_intro_path=module_intro_source,
            course_id=course_id,
            skip_hidden=skip_hidden,
            custom_terms=_custom_terms(custom_terms_raw),
            check_external_links=False,
            include_file_inventory=include_file_inventory,
            file_inventory_only=file_inventory_only,
        )
    except CartridgeError as exc:
        return json.dumps({"error": str(exc)})

    if file_inventory_only:
        suffix = "_course_file_maintenance_report.html"
    else:
        suffix = "_combined_accessibility_report.html" if module_intro_source else "_accessibility_report.html"
    source_name = source.name
    if module_intro_source:
        source_name = f"{source.name} + module intros from {module_intro_source.name}"
    return _report_result(findings, search_records, f"{source.stem}{suffix}", source_name, course_id=course_id)


def run_quick_check(markup: str) -> str:
    findings, search_records = scan_pasted_html(markup)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return _report_result(findings, search_records, f"quick_check_{timestamp}_accessibility_report.html", "Quick Check - pasted HTML")


def load_quiz(primary_path: str, skip_hidden: bool = True) -> str:
    try:
        records = load_quiz_library(Path(primary_path), skip_hidden=skip_hidden)
    except CartridgeError as exc:
        return json.dumps({"error": str(exc)})
    return json.dumps(
        {
            "records": [
                {
                    "folder": record.folder,
                    "associated_quiz": record.associated_quiz,
                    "question_text": record.question_text,
                    "source_file": record.source_file,
                    "answer_choices": list(record.answer_choices),
                    "correct_answer_choices": list(record.correct_answer_choices),
                }
                for record in records
            ]
        }
    )


def _report_result(
    findings: list[Finding],
    search_records: list[SearchRecord],
    filename: str,
    source_name: str,
    course_id: str = "",
) -> str:
    report_dir = Path(tempfile.mkdtemp(prefix="report_", dir=_work_root()))
    try:
        output = report_dir / filename
        write_html_report(findings, output, source_name, search_records=search_records)
        html = output.read_text(encoding="utf-8")
    finally:
        shutil.rmtree(report_dir, ignore_errors=True)
    return json.dumps({"count": len(findings), "filename": filename, "html": html, "course_id": course_id})


def _work_root() -> Path:
    WORK_ROOT.mkdir(parents=True, exist_ok=True)
    return WORK_ROOT


def _custom_terms(raw: str) -> list[str]:
    raw = (raw or "").replace(",", "\n").replace(";", "\n")
    return [term.strip() for term in raw.splitlines() if term.strip()]
