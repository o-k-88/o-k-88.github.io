"""Brightspace Common Cartridge accessibility checker."""

__version__ = "1.56"
