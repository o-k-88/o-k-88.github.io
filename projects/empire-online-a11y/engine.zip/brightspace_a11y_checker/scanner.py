from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

from .cartridge import BRIGHTSPACE_COURSE_BASE, content_root_from_export_name, discover_course_items, extract_cartridge
from .external_links import ExternalLinkChecker, external_link_findings_for_item
from .file_inventory import scan_course_file_inventory
from .models import Confidence, Finding, SearchRecord, Severity
from .rules import scan_html, scan_xml
from .rules.html import html_search_record
from .rules.manifest import scan_manifest_module_intros
from .rules.xml import xml_search_records


def scan_cartridge(
    cartridge_path: Path,
    course_id: str = "",
    skip_hidden: bool = False,
    custom_terms: list[str] | None = None,
    check_external_links: bool = False,
    link_checker: ExternalLinkChecker | None = None,
) -> list[Finding]:
    findings, _search_records = scan_cartridge_with_index(
        cartridge_path,
        course_id=course_id,
        skip_hidden=skip_hidden,
        custom_terms=custom_terms,
        check_external_links=check_external_links,
        link_checker=link_checker,
    )
    return findings


def scan_cartridge_with_index(
    cartridge_path: Path,
    course_id: str = "",
    skip_hidden: bool = False,
    custom_terms: list[str] | None = None,
    check_external_links: bool = False,
    link_checker: ExternalLinkChecker | None = None,
    include_file_inventory: bool = False,
) -> tuple[list[Finding], list[SearchRecord]]:
    extracted = extract_cartridge(cartridge_path)
    try:
        content_root = content_root_from_export_name(cartridge_path)
        items = discover_course_items(extracted.temp_dir, course_id=course_id, skip_hidden=skip_hidden, content_root=content_root)
        findings: list[Finding] = []
        search_records: list[SearchRecord] = []

        external_link_checker = link_checker or ExternalLinkChecker()
        for item in items:
            if item.content_type == "HTML content page":
                search_records.append(html_search_record(item))
                findings.extend(scan_html(item))
            elif item.content_type == "Brightspace XML content":
                search_records.extend(xml_search_records(item))
                findings.extend(scan_xml(item))
            if check_external_links:
                findings.extend(external_link_findings_for_item(item, external_link_checker))

        manifest_findings, manifest_search_records = scan_manifest_module_intros(
            extracted.temp_dir / "imsmanifest.xml",
            location_url=f"{BRIGHTSPACE_COURSE_BASE}/{course_id}/Home" if course_id else "",
            skip_hidden=skip_hidden,
            content_root=content_root,
        )
        findings.extend(manifest_findings)
        search_records.extend(manifest_search_records)
        findings.extend(_custom_keyword_findings(search_records, custom_terms or []))
        if include_file_inventory:
            findings.extend(scan_course_file_inventory(cartridge_path, skip_hidden=skip_hidden))

        return findings, search_records
    finally:
        extracted.cleanup()


def scan_combined_exports(
    primary_path: Path,
    module_intro_path: Path | None = None,
    course_id: str = "",
    skip_hidden: bool = False,
    custom_terms: list[str] | None = None,
    check_external_links: bool = False,
    include_file_inventory: bool = False,
    file_inventory_only: bool = False,
) -> tuple[list[Finding], list[SearchRecord]]:
    inventory_source = module_intro_path or primary_path
    if file_inventory_only:
        if not include_file_inventory:
            return [], []
        return scan_course_file_inventory(inventory_source, skip_hidden=skip_hidden), []

    findings, search_records = scan_cartridge_with_index(
        primary_path,
        course_id=course_id,
        skip_hidden=skip_hidden,
        check_external_links=check_external_links,
        include_file_inventory=False,
    )
    if not module_intro_path:
        if include_file_inventory:
            findings.extend(scan_course_file_inventory(primary_path, skip_hidden=skip_hidden))
        findings.extend(_custom_keyword_findings(search_records, custom_terms or []))
        return findings, search_records

    extracted = extract_cartridge(module_intro_path)
    try:
        manifest_findings, manifest_search_records = scan_manifest_module_intros(
            extracted.temp_dir / "imsmanifest.xml",
            location_url=f"{BRIGHTSPACE_COURSE_BASE}/{course_id}/Home" if course_id else "",
            skip_hidden=skip_hidden,
            module_intros_only=True,
            content_root=content_root_from_export_name(module_intro_path),
        )
        findings.extend(manifest_findings)
        search_records.extend(manifest_search_records)
        if include_file_inventory:
            findings.extend(scan_course_file_inventory(module_intro_path, skip_hidden=skip_hidden))
        findings.extend(_custom_keyword_findings(search_records, custom_terms or []))
        return findings, search_records
    finally:
        extracted.cleanup()


@dataclass(frozen=True)
class _KeywordQuery:
    expression: str
    include_groups: tuple[tuple[str, ...], ...]
    exclude_terms: tuple[str, ...]

    def matches(self, text: str) -> bool:
        if any(_keyword_term_match(text, term) for term in self.exclude_terms):
            return False
        return any(all(_keyword_term_match(text, term) for term in group) for group in self.include_groups)

    def first_matched_term(self, text: str) -> str:
        for group in self.include_groups:
            for term in group:
                if _keyword_term_match(text, term):
                    return term
        return ""


def _custom_keyword_findings(search_records: list[SearchRecord], custom_terms: list[str]) -> list[Finding]:
    queries = _custom_keyword_queries(custom_terms)
    if not queries:
        return []
    findings: list[Finding] = []
    seen: set[tuple[str, str, str]] = set()
    for record in search_records:
        searchable = record.text or ""
        for query in queries:
            if not query.matches(searchable):
                continue
            key = (record.title, record.source, query.expression.lower())
            if key in seen:
                continue
            seen.add(key)
            findings.append(
                Finding(
                    location=record.title,
                    content_type=record.content_type,
                    issue="Custom keyword appears in page text.",
                    wcag="Manual review",
                    severity=Severity.LOW,
                    confidence=Confidence.MANUAL_REVIEW,
                    evidence=_custom_keyword_evidence(searchable, query),
                    recommendation="Review this page because it matches a custom word, phrase, or Boolean search requested before the scan.",
                    source="Custom Keyword Scan",
                )
            )
    return findings


def _custom_keyword_queries(custom_terms: list[str]) -> list[_KeywordQuery]:
    seen: set[str] = set()
    queries: list[_KeywordQuery] = []
    for value in custom_terms:
        query = _parse_keyword_query(value)
        if not query:
            continue
        key = query.expression.lower()
        if key in seen:
            continue
        seen.add(key)
        queries.append(query)
    return queries


def _parse_keyword_query(value: str) -> _KeywordQuery | None:
    expression = " ".join(value.split()).strip()
    if len(expression) < 2:
        return None
    groups: list[list[str]] = [[]]
    exclude_terms: list[str] = []
    negate_next = False
    for token in _keyword_tokens(expression):
        upper = token.upper()
        if upper == "AND":
            continue
        if upper == "OR":
            if groups[-1]:
                groups.append([])
            continue
        if upper == "NOT":
            negate_next = True
            continue
        negative = negate_next or token.startswith("-")
        term = token[1:] if token.startswith("-") else token
        term = term.strip()
        negate_next = False
        if len(term) < 2:
            continue
        if negative:
            exclude_terms.append(term)
        else:
            groups[-1].append(term)
    include_groups = tuple(tuple(group) for group in groups if group)
    if not include_groups:
        return None
    return _KeywordQuery(expression=expression, include_groups=include_groups, exclude_terms=tuple(exclude_terms))


def _keyword_tokens(expression: str) -> list[str]:
    tokens: list[str] = []
    for match in re.finditer(r'"([^"]+)"|(\S+)', expression):
        token = match.group(1) if match.group(1) is not None else match.group(2)
        token = token.strip().strip("()")
        if token:
            tokens.append(token)
    return tokens


def _keyword_term_pattern(term: str) -> re.Pattern[str]:
    parts = [re.escape(part) for part in re.split(r"\s+", term.strip()) if part]
    phrase = r"\s+".join(parts)
    return re.compile(rf"(?<!\w){phrase}(?!\w)", re.IGNORECASE)


def _keyword_term_match(text: str, term: str) -> re.Match[str] | None:
    return _keyword_term_pattern(term).search(text) if term.strip() else None


def _custom_keyword_evidence(text: str, query: _KeywordQuery) -> str:
    term = query.first_matched_term(text)
    match = _keyword_term_match(text, term) if term else None
    if not match:
        return f"Keyword search: {query.expression}"
    start = max(0, match.start() - 90)
    end = min(len(text), match.end() + 120)
    snippet = " ".join(text[start:end].split())
    prefix = "..." if start > 0 else ""
    suffix = "..." if end < len(text) else ""
    return f"Keyword search: {query.expression}\nMatched term: {term}\nContext: {prefix}{snippet}{suffix}"
