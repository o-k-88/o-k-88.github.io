from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class Severity(str, Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class Confidence(str, Enum):
    AUTOMATED = "Automated"
    MANUAL_REVIEW = "Manual review"


@dataclass(frozen=True)
class CourseItem:
    title: str
    path: Path
    content_type: str
    location_url: str = ""
    content_root: str = ""


@dataclass(frozen=True)
class Finding:
    location: str
    content_type: str
    issue: str
    wcag: str
    severity: Severity
    confidence: Confidence
    evidence: str
    recommendation: str
    suggested_fix: str = ""
    source: str = "Cartridge Scan"
    location_url: str = ""


@dataclass(frozen=True)
class SearchRecord:
    title: str
    text: str
    content_type: str
    source: str
