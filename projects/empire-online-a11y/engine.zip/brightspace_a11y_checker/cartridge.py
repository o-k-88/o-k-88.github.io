from __future__ import annotations

import shutil
import zipfile
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from uuid import uuid4

from .models import CourseItem


BRIGHTSPACE_COURSE_BASE = "https://myclasses.sunyempire.edu/d2l/le/content"
HTML_EXTENSIONS = {".html", ".htm", ".xhtml"}
XML_EXTENSIONS = {".xml", ".qti"}
SCANNABLE_EXTENSIONS = HTML_EXTENSIONS | XML_EXTENSIONS
TOOL_XML_FILENAMES = {"dropbox_d2l.xml", "grades_d2l.xml", "questiondb.xml"}
MAX_WINDOWS_PATH = 240


class CartridgeError(Exception):
    pass


def course_id_from_export_name(path: Path) -> str:
    match = re.search(r"D2L(?:CC)?Export[_-](\d+)", path.stem, re.IGNORECASE)
    return match.group(1) if match else ""


def content_root_from_export_name(path: Path) -> str:
    match = re.search(r"D2L(?:CC)?Export[_-](\d+)[_-](.+?)(?:_\d+)?$", path.stem, re.IGNORECASE)
    if not match:
        return ""
    course_folder = f"{match.group(1)}-{match.group(2).strip('_-')}"
    return f"/content/enforced/{course_folder}/"


def course_id_from_url_or_text(value: str) -> str:
    match = re.search(r"/content/(\d+)(?:/|$)", value)
    if match:
        return match.group(1)
    match = re.search(r"^\s*(\d+)\s*$", value)
    return match.group(1) if match else ""


class ExtractedCartridge:
    def __init__(self, source: Path) -> None:
        self.source = source
        self.temp_dir = source.parent / f".a11y_{uuid4().hex[:8]}"
        self.temp_dir.mkdir(parents=True, exist_ok=False)
        self.skipped_members: list[str] = []

    def cleanup(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)


def extract_cartridge(path: Path) -> ExtractedCartridge:
    if path.suffix.lower() not in {".imscc", ".zip"}:
        raise CartridgeError("Please choose a Brightspace .imscc Common Cartridge or D2LExport .zip file.")

    extracted = ExtractedCartridge(path)
    try:
        with zipfile.ZipFile(path) as archive:
            for member in archive.infolist():
                if member.is_dir():
                    continue
                if not _should_extract(member.filename):
                    continue
                try:
                    _extract_member(archive, member, extracted.temp_dir)
                except OSError:
                    extracted.skipped_members.append(member.filename)
    except zipfile.BadZipFile as exc:
        extracted.cleanup()
        raise CartridgeError("The selected .imscc file could not be opened as a cartridge.") from exc

    return extracted


def _should_extract(filename: str) -> bool:
    suffix = Path(filename).suffix.lower()
    return suffix in SCANNABLE_EXTENSIONS or Path(filename).name.lower() == "imsmanifest.xml"


def _extract_member(archive: zipfile.ZipFile, member: zipfile.ZipInfo, root: Path) -> None:
    destination = _safe_destination(root, member.filename)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with archive.open(member) as source, destination.open("wb") as target:
        shutil.copyfileobj(source, target)


def _safe_destination(root: Path, member_name: str) -> Path:
    parts = [part for part in Path(member_name.replace("\\", "/")).parts if part not in {"", ".", ".."}]
    destination = root.joinpath(*parts)
    if len(str(destination)) <= MAX_WINDOWS_PATH:
        return destination

    suffix = destination.suffix
    short_name = f"longpath_{uuid4().hex}{suffix}"
    return root / "_long_paths" / short_name


def discover_course_items(root: Path, course_id: str = "", skip_hidden: bool = False, content_root: str = "") -> list[CourseItem]:
    items: list[CourseItem] = []
    course_home_url = f"{BRIGHTSPACE_COURSE_BASE}/{course_id}/Home" if course_id else ""
    hidden_files = _hidden_manifest_files(root) if skip_hidden else set()
    attached_files = _live_attached_files(root, skip_hidden=skip_hidden)

    for path in root.rglob("*"):
        if not path.is_file():
            continue

        suffix = path.suffix.lower()
        rel = path.relative_to(root)
        title = str(rel)
        normalized_rel = _normalize_manifest_path(title)
        if normalized_rel in hidden_files:
            continue
        if attached_files and normalized_rel not in attached_files:
            continue
        if path.name.lower().startswith("missing-"):
            continue

        if suffix in HTML_EXTENSIONS and _skip_html_file(path.name):
            continue

        if suffix in HTML_EXTENSIONS:
            items.append(CourseItem(title=title, path=path, content_type="HTML content page", location_url=course_home_url, content_root=content_root))
        elif suffix in XML_EXTENSIONS and path.name.lower() != "imsmanifest.xml":
            items.append(CourseItem(title=title, path=path, content_type="Brightspace XML content", location_url=course_home_url, content_root=content_root))

    return items


def _live_attached_files(root: Path, skip_hidden: bool = False) -> set[str]:
    manifest = root / "imsmanifest.xml"
    if not manifest.exists():
        return set()

    try:
        tree = ET.parse(manifest)
    except ET.ParseError:
        return set()

    root_element = tree.getroot()
    resource_files: dict[str, list[str]] = {}
    for resource in root_element.iter():
        if _local_name(resource.tag) != "resource":
            continue
        identifier = resource.attrib.get("identifier", "")
        files = [
            _normalize_manifest_path(file_element.attrib.get("href", ""))
            for file_element in resource
            if _local_name(file_element.tag) == "file" and file_element.attrib.get("href")
        ]
        if identifier:
            resource_files[identifier] = files

    attached: set[str] = set()
    has_manifest_items = False
    for item in root_element.iter():
        if _local_name(item.tag) != "item":
            continue
        identifierref = item.attrib.get("identifierref", "")
        if not identifierref:
            continue
        has_manifest_items = True
        if skip_hidden and _is_hidden_item(item):
            continue
        attached.update(resource_files.get(identifierref, []))

    for files in resource_files.values():
        for file_path in files:
            if _is_tool_xml_file(file_path):
                attached.add(file_path)
    if not has_manifest_items:
        for files in resource_files.values():
            attached.update(files)

    return attached


def _is_tool_xml_file(path: str) -> bool:
    return Path(path.replace("\\", "/")).name.lower() in TOOL_XML_FILENAMES


def _is_hidden_assignment_folder(element: ET.Element) -> bool:
    for key, value in element.attrib.items():
        local_key = key.split("}", 1)[-1].lower()
        if local_key in {"is_hidden", "hidden", "folder_is_hidden", "isvisible", "visible"}:
            normalized = value.strip().lower()
            if normalized in {"true", "1", "yes"} and local_key not in {"isvisible", "visible"}:
                return True
            if normalized in {"false", "0", "no"} and local_key in {"isvisible", "visible"}:
                return True
    return False


def _hidden_manifest_files(root: Path) -> set[str]:
    manifest = root / "imsmanifest.xml"
    if not manifest.exists():
        return set()

    try:
        tree = ET.parse(manifest)
    except ET.ParseError:
        return set()

    root_element = tree.getroot()
    resource_files: dict[str, list[str]] = {}
    for resource in root_element.iter():
        if _local_name(resource.tag) != "resource":
            continue
        identifier = resource.attrib.get("identifier", "")
        files = [
            _normalize_manifest_path(file_element.attrib.get("href", ""))
            for file_element in resource
            if _local_name(file_element.tag) == "file" and file_element.attrib.get("href")
        ]
        if identifier:
            resource_files[identifier] = files

    hidden: set[str] = set()
    for item in root_element.iter():
        if _local_name(item.tag) != "item":
            continue
        if not _is_hidden_item(item):
            continue
        identifierref = item.attrib.get("identifierref", "")
        hidden.update(resource_files.get(identifierref, []))

    return hidden


def _is_hidden_item(element: ET.Element) -> bool:
    for key, value in element.attrib.items():
        local_key = key.split("}", 1)[-1].lower()
        if local_key in {"isvisible", "visible"} and value.strip().lower() in {"false", "0", "no"}:
            return True
    return False


def _skip_html_file(filename: str) -> bool:
    normalized = filename.lower()
    return normalized.startswith("label-") or normalized == "conversionreport.html"


def _local_name(tag: str) -> str:
    return tag.split("}", 1)[-1]


def _normalize_manifest_path(path: str) -> str:
    return path.replace("\\", "/").replace("сontent/", "content/").lstrip("./")
