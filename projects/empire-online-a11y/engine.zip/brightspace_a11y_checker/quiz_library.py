﻿from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from .cartridge import CartridgeError, content_root_from_export_name, discover_course_items, extract_cartridge
from .models import CourseItem
from .rules.xml import (
    _assessment_title,
    _extract_fragments_from_element,
    _extract_question_name_from_element,
    _local_name,
    _looks_like_qti,
    _plain_text_from_xml_value,
    _qti_question_folders,
)


@dataclass(frozen=True)
class QuizLibraryRecord:
    folder: str
    associated_quiz: str
    question_text: str
    source_file: str
    answer_choices: tuple[str, ...] = field(default_factory=tuple)
    correct_answer_choices: tuple[str, ...] = field(default_factory=tuple)


def load_quiz_library(export_path: Path, skip_hidden: bool = False) -> list[QuizLibraryRecord]:
    extracted = extract_cartridge(export_path)
    try:
        content_root = content_root_from_export_name(export_path)
        items = discover_course_items(extracted.temp_dir, skip_hidden=skip_hidden, content_root=content_root)
        records: list[QuizLibraryRecord] = []
        for item in items:
            if item.content_type != "Brightspace XML content":
                continue
            records.extend(_quiz_records_from_item(item))
        return sorted(records, key=lambda record: (record.folder.lower(), record.associated_quiz.lower(), record.question_text.lower()))
    except CartridgeError:
        raise
    finally:
        extracted.cleanup()


def _quiz_records_from_item(item: CourseItem) -> list[QuizLibraryRecord]:
    raw_xml = item.path.read_text(encoding="utf-8", errors="replace")
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return []
    if not _looks_like_qti(item, root):
        return []

    assessment_title = _assessment_title(root) or _xml_title(root) or item.path.stem
    question_items = [element for element in root.iter() if _local_name(element.tag).lower() == "item"]
    if not question_items:
        question_text = _question_text(root)
        if not question_text:
            return []
        choice_items = _answer_choice_items(root)
        return [
            QuizLibraryRecord(
                folder=assessment_title,
                associated_quiz=_associated_quiz_label(assessment_title, item),
                question_text=question_text,
                source_file=item.title.replace("\\", "/"),
                answer_choices=tuple(choice[1] for choice in choice_items),
                correct_answer_choices=_correct_answer_choices(root, choice_items),
            )
        ]

    records: list[QuizLibraryRecord] = []
    question_folders = _qti_question_folders(root, assessment_title)
    for index, question in enumerate(question_items, start=1):
        choice_items = _answer_choice_items(question)
        choices = tuple(choice[1] for choice in choice_items)
        question_text = _question_prompt_text(question) or _extract_question_name_from_element(question) or f"Question {index}"
        folder = question_folders.get(id(question), assessment_title) or assessment_title
        records.append(
            QuizLibraryRecord(
                folder=folder,
                associated_quiz=_associated_quiz_label(assessment_title, item),
                question_text=question_text,
                source_file=item.title.replace("\\", "/"),
                answer_choices=choices,
                correct_answer_choices=_correct_answer_choices(question, choice_items),
            )
        )
    return records


def _associated_quiz_label(assessment_title: str, item: CourseItem) -> str:
    normalized = assessment_title.strip()
    if normalized and normalized.lower() not in {"quiz library", "question library", "questiondb", "questions"}:
        return normalized
    title = item.title.replace("\\", "/")
    if "/" in title:
        parent = title.split("/", 1)[0].strip()
        if parent.lower() in {"quiz", "quizzes", "survey", "surveys"} and normalized:
            return normalized
    return "No quiz association found in export"


def _question_prompt_text(element: ET.Element) -> str:
    values: list[str] = []

    def walk(node: ET.Element, in_choice: bool = False) -> None:
        local = _local_name(node.tag).lower()
        next_in_choice = in_choice or local in {"response_label", "responsechoice", "choice", "simplechoice"}
        if not next_in_choice and local in {"mattext", "questiontext", "prompt", "description", "text"} and node.text and node.text.strip():
            values.append(_plain_text_from_xml_value(node.text))
        for child in list(node):
            walk(child, next_in_choice)

    walk(element)
    return " ".join(" ".join(values).split())


def _question_text(element: ET.Element) -> str:
    fragments = _extract_fragments_from_element(element)
    text = " ".join(_plain_text_from_xml_value(fragment) for fragment in fragments)
    text = " ".join(text.split())
    if text:
        return text
    values: list[str] = []
    for child in element.iter():
        if child.text and child.text.strip():
            values.append(_plain_text_from_xml_value(child.text))
        for value in child.attrib.values():
            if value.strip():
                values.append(_plain_text_from_xml_value(value))
    return " ".join(" ".join(values).split())


def _answer_choice_items(element: ET.Element) -> tuple[tuple[str, str, bool], ...]:
    choices: list[tuple[str, str, bool]] = []
    seen_text: set[str] = set()
    for candidate in element.iter():
        if _local_name(candidate.tag).lower() not in {"response_label", "responsechoice", "choice", "simplechoice"}:
            continue
        text = _choice_text(candidate)
        if not text or text in seen_text:
            continue
        seen_text.add(text)
        identifier = candidate.attrib.get("ident", "") or candidate.attrib.get("identifier", "") or candidate.attrib.get("id", "")
        choices.append((identifier.strip(), text, _choice_marked_correct(candidate)))
    return tuple(choices)


def _correct_answer_choices(element: ET.Element, choices: tuple[tuple[str, str, bool], ...]) -> tuple[str, ...]:
    correct_ids = _correct_choice_ids(element)
    correct: list[str] = []
    for identifier, text, marked_correct in choices:
        if marked_correct or identifier and identifier in correct_ids:
            correct.append(text)
    return tuple(correct)


def _correct_choice_ids(element: ET.Element) -> set[str]:
    correct_ids: set[str] = set()
    for condition in element.iter():
        if _local_name(condition.tag).lower() != "respcondition":
            continue
        if not _respcondition_is_correct(condition):
            continue
        for candidate in condition.iter():
            local = _local_name(candidate.tag).lower()
            if local not in {"varequal", "varsubset"}:
                continue
            value = _plain_text_from_xml_value(candidate.text or "").strip()
            if value:
                correct_ids.add(value)
    return correct_ids


def _respcondition_is_correct(condition: ET.Element) -> bool:
    for value in condition.attrib.values():
        if _has_correct_token(value):
            return True
    for child in condition.iter():
        local = _local_name(child.tag).lower()
        if local == "setvar":
            try:
                return float((child.text or "0").strip()) > 0
            except ValueError:
                continue
        if local == "displayfeedback":
            feedback = " ".join(child.attrib.values())
            if _has_correct_token(feedback):
                return True
    return False


def _has_correct_token(value: str) -> bool:
    return bool(re.search(r"\b(correct|right)\b", value or "", flags=re.IGNORECASE))


def _choice_marked_correct(element: ET.Element) -> bool:
    for key, value in element.attrib.items():
        normalized_key = key.lower().replace("_", "").replace("-", "")
        if normalized_key in {"correct", "iscorrect"} and value.strip().lower() in {"1", "true", "yes"}:
            return True
    return False


def _choice_text(element: ET.Element) -> str:
    values: list[str] = []
    for child in element.iter():
        if child is element and child.text and child.text.strip():
            values.append(_plain_text_from_xml_value(child.text))
        elif _local_name(child.tag).lower() in {"mattext", "text", "description"} and child.text and child.text.strip():
            values.append(_plain_text_from_xml_value(child.text))
    return " ".join(" ".join(values).split())


def _xml_title(root: ET.Element) -> str:
    for element in root.iter():
        if _local_name(element.tag).lower() == "title" and element.text and element.text.strip():
            return element.text.strip()
    return ""

