from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from .models import CourseItem, Finding, SearchRecord
from .rules.html import html_page_name_from_markup, html_search_record_from_markup, scan_html_markup


def scan_pasted_html(markup: str) -> tuple[list[Finding], list[SearchRecord]]:
    """Scan one pasted HTML page with the standard HTML-page rules."""
    item = CourseItem(
        title="Pasted HTML page",
        path=Path("quick_check.html"),
        content_type="HTML content page",
    )
    findings = [replace(finding, source="Quick Check") for finding in scan_html_markup(item, markup)]
    search_record = html_search_record_from_markup(item, markup, title=html_page_name_from_markup(markup))
    return findings, [replace(search_record, source="Quick Check")]