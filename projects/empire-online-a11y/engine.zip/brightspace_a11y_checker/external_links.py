from __future__ import annotations

from dataclasses import dataclass
import html
from html.parser import HTMLParser
from socket import timeout as SocketTimeout
import ssl
from typing import Callable, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urldefrag, urlparse, urlsplit, urlunsplit
from urllib.request import Request, urlopen

from .models import Confidence, CourseItem, Finding, Severity


class UrlResponse(Protocol):
    status: int

    def getcode(self) -> int: ...


UrlOpener = Callable[[Request, float], UrlResponse]


@dataclass(frozen=True)
class LinkReference:
    href: str
    text: str


@dataclass(frozen=True)
class LinkCheckResult:
    url: str
    status: int | None
    reason: str


class ExternalLinkChecker:
    def __init__(self, timeout: float = 8.0, opener: UrlOpener | None = None) -> None:
        self.timeout = timeout
        self._opener = opener or _open_url
        self._cache: dict[str, LinkCheckResult | None] = {}

    def check(self, url: str) -> LinkCheckResult | None:
        normalized = _normalized_url(url)
        if normalized in self._cache:
            return self._cache[normalized]
        result = self._check_uncached(normalized)
        self._cache[normalized] = result
        return result

    def _check_uncached(self, url: str) -> LinkCheckResult | None:
        status, reason = self._request_status(url, "HEAD")
        if status == 405:
            status, reason = self._request_status(url, "GET")
        if status in {404, 410}:
            return LinkCheckResult(url=url, status=status, reason=reason or _status_reason(status))
        return None

    def _request_status(self, url: str, method: str) -> tuple[int | None, str]:
        try:
            request = Request(
                url,
                method=method,
                headers={"User-Agent": "Empire Online A11y link checker"},
            )
            response = self._opener(request, self.timeout)
            status = getattr(response, "status", None) or response.getcode()
            return int(status), _status_reason(int(status))
        except HTTPError as exc:
            return int(exc.code), exc.reason or _status_reason(int(exc.code))
        except (URLError, TimeoutError, SocketTimeout, ssl.SSLError, OSError, UnicodeError, ValueError) as exc:
            return None, str(exc)


def external_link_findings_for_item(item: CourseItem, checker: ExternalLinkChecker) -> list[Finding]:
    if _is_quiz_or_survey_xml(item):
        return []
    markup = item.path.read_text(encoding="utf-8", errors="replace")
    links = _extract_links(markup)
    findings: list[Finding] = []
    seen: set[str] = set()
    for link in links:
        if not _is_external_http_url(link.href):
            continue
        normalized = _normalized_url(link.href)
        if normalized in seen:
            continue
        seen.add(normalized)
        result = checker.check(link.href)
        if result is None:
            continue
        findings.append(
            Finding(
                location=item.title,
                content_type=item.content_type,
                issue="External link appears to be broken.",
                wcag="2.4.4 Link Purpose (In Context); Course quality / content maintenance",
                severity=Severity.HIGH,
                confidence=Confidence.AUTOMATED,
                evidence=_broken_link_evidence(link, result),
                recommendation="Update, replace, or remove the external link because it returned a broken-link status during the optional external link check.",
                suggested_fix=_link_fix(link),
                source="External Link Check",
                location_url=item.location_url,
            )
        )
    return findings


def _open_url(request: Request, timeout: float) -> UrlResponse:
    return urlopen(request, timeout=timeout)


def _is_quiz_or_survey_xml(item: CourseItem) -> bool:
    if item.content_type != "Brightspace XML content":
        return False
    normalized_title = item.title.replace("\\", "/").lower()
    filename = item.path.name.lower()
    return (
        normalized_title.startswith(("quiz/", "survey/"))
        or filename == "questiondb.xml"
        or filename.startswith(("quiz_d2l_", "survey_d2l_"))
        or "/qti_" in normalized_title
        or "/quiz" in normalized_title
        or "/survey" in normalized_title
    )
def _extract_links(markup: str) -> list[LinkReference]:
    parser = _LinkExtractor()
    parser.feed(html.unescape(markup))
    return parser.links


def _is_external_http_url(href: str) -> bool:
    parsed = urlparse(href)
    if parsed.scheme not in {"http", "https"}:
        return False
    return parsed.netloc.lower() != "myclasses.sunyempire.edu"


def _normalized_url(url: str) -> str:
    without_fragment, _fragment = urldefrag(url.strip())
    parsed = urlsplit(without_fragment)
    try:
        hostname = parsed.hostname.encode("idna").decode("ascii") if parsed.hostname else ""
    except UnicodeError:
        hostname = parsed.hostname or ""
    if parsed.port:
        hostname = f"{hostname}:{parsed.port}"
    if parsed.username:
        credentials = quote(parsed.username, safe="")
        if parsed.password:
            credentials += ":" + quote(parsed.password, safe="")
        hostname = f"{credentials}@{hostname}"
    path = quote(parsed.path, safe="/%:@!$&'()*+,;=-._~")
    query = quote(parsed.query, safe="=&?/:@!$'()*+,;%-._~")
    return urlunsplit((parsed.scheme, hostname, path, query, ""))


def _status_reason(status: int) -> str:
    if status == 404:
        return "Not Found"
    if status == 410:
        return "Gone"
    if status == 405:
        return "Method Not Allowed"
    return f"HTTP {status}"


def _broken_link_evidence(link: LinkReference, result: LinkCheckResult) -> str:
    status = f"{result.status} {result.reason}" if result.status is not None else result.reason
    lines = [f"URL: {result.url}", f"Status: {status}"]
    if link.text:
        lines.append(f"Link text: {link.text}")
    return "\n".join(lines)


def _link_fix(link: LinkReference) -> str:
    text = html.escape(link.text or "Descriptive link text")
    return f'<a href="REPLACE-WITH-WORKING-URL" target="_blank">{text}</a>'


class _LinkExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[LinkReference] = []
        self._active: list[dict[str, object]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "a":
            return
        attr_map = {name.lower(): value or "" for name, value in attrs}
        href = attr_map.get("href", "").strip()
        if href:
            self._active.append({"href": href, "text": []})

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() != "a" or not self._active:
            return
        active = self._active.pop()
        text = " ".join("".join(active["text"]).split())
        self.links.append(LinkReference(href=str(active["href"]), text=text))

    def handle_data(self, data: str) -> None:
        if self._active:
            self._active[-1]["text"].append(data)
