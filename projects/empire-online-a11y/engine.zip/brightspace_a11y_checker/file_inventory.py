from __future__ import annotations

from collections import defaultdict
import hashlib
from pathlib import Path, PurePosixPath
import re
from urllib.parse import unquote, urlsplit
import zipfile
import xml.etree.ElementTree as ET

from .models import Confidence, Finding, Severity


INVENTORY_EXTENSIONS = {".doc", ".docx", ".ppt", ".pptx", ".mov", ".mp4"}
TEXT_REFERENCE_EXTENSIONS = {".css", ".htm", ".html", ".qti", ".xhtml", ".xml"}
LARGE_FILE_BYTES = 2 * 1024 * 1024
SOURCE = "Course File Maintenance"


def scan_course_file_inventory(cartridge_path: Path, skip_hidden: bool = False) -> list[Finding]:
    """Inspect package metadata and references without opening document contents."""
    if cartridge_path.suffix.lower() not in {".imscc", ".zip"}:
        return []

    with zipfile.ZipFile(cartridge_path) as archive:
        members = {
            _normalize_path(member.filename): member
            for member in archive.infolist()
            if not member.is_dir() and _normalize_path(member.filename)
        }
        manifest = _read_manifest(archive, members)
        attached, manifest_linked = _manifest_file_sets(manifest, skip_hidden=skip_hidden)
        candidates = {
            path: member
            for path, member in members.items()
            if PurePosixPath(path).suffix.lower() in INVENTORY_EXTENSIONS or path in attached
        }
        if not candidates:
            return []

        referenced = manifest_linked | _content_references(archive, members, set(candidates))
        digests = {path: _member_digest(archive, member) for path, member in candidates.items()}
        names: dict[str, list[str]] = defaultdict(list)
        hashes: dict[str, list[str]] = defaultdict(list)
        for path, digest in digests.items():
            names[PurePosixPath(path).name.casefold()].append(path)
            hashes[digest].append(path)

        findings: list[Finding] = []
        for path, member in sorted(candidates.items()):
            size = member.file_size
            if size > LARGE_FILE_BYTES:
                findings.append(_finding(
                    path,
                    "Course file is larger than 2 MiB.",
                    Severity.MEDIUM,
                    f"File: {path}\nSize: {_format_size(size)} ({size:,} bytes)",
                    "Review whether this file can be compressed, replaced with a smaller version, or hosted in an appropriate streaming or document service.",
                ))

            if path not in referenced:
                findings.append(_finding(
                    path,
                    "Course file may not be linked in the course.",
                    Severity.LOW,
                    f"File: {path}\nNo visible course reference was found in the exported package.",
                    "Confirm the file is unused in Brightspace before deleting it. References created dynamically may not be visible in an export.",
                ))

            same_name = [other for other in names[PurePosixPath(path).name.casefold()] if other != path]
            if same_name:
                identical = [other for other in same_name if digests[other] == digests[path]]
                different = [other for other in same_name if digests[other] != digests[path]]
                details = []
                if identical:
                    details.append("Identical content:\n" + "\n".join(identical))
                if different:
                    details.append("Different content with the same filename:\n" + "\n".join(different))
                findings.append(_finding(
                    path,
                    "Duplicate course filename found.",
                    Severity.MEDIUM if different else Severity.LOW,
                    f"File: {path}\n" + "\n".join(details),
                    "Review these files and retain the intended version. Same-name files with different content can cause version confusion.",
                ))

            same_content = [other for other in hashes[digests[path]] if other != path]
            differently_named = [other for other in same_content if PurePosixPath(other).name.casefold() != PurePosixPath(path).name.casefold()]
            if differently_named:
                findings.append(_finding(
                    path,
                    "Duplicate course file content found under different filenames.",
                    Severity.LOW,
                    f"File: {path}\nIdentical content:\n" + "\n".join(differently_named),
                    "Confirm whether each copy is needed. Removing redundant files can reduce course storage.",
                ))
        return findings


def _read_manifest(archive: zipfile.ZipFile, members: dict[str, zipfile.ZipInfo]) -> ET.Element | None:
    member = members.get("imsmanifest.xml")
    if not member:
        return None
    try:
        return ET.fromstring(archive.read(member))
    except (ET.ParseError, OSError):
        return None


def _manifest_file_sets(root: ET.Element | None, skip_hidden: bool) -> tuple[set[str], set[str]]:
    if root is None:
        return set(), set()
    resources: dict[str, tuple[str, set[str]]] = {}
    for element in root.iter():
        if _local_name(element.tag) != "resource":
            continue
        identifier = element.attrib.get("identifier", "")
        primary = _normalize_path(element.attrib.get("href", ""))
        files = {
            _normalize_path(child.attrib.get("href", ""))
            for child in element
            if _local_name(child.tag) == "file" and child.attrib.get("href")
        }
        if identifier:
            resources[identifier] = (primary, {path for path in files if path})

    attached: set[str] = set()
    linked: set[str] = set()
    for item in root.iter():
        if _local_name(item.tag) != "item" or (skip_hidden and _is_hidden(item)):
            continue
        identifierref = item.attrib.get("identifierref", "")
        primary, files = resources.get(identifierref, ("", set()))
        linked.update(files)
        if primary:
            linked.add(primary)
            if PurePosixPath(primary).suffix.lower() not in {".htm", ".html", ".xhtml", ".xml", ".qti"}:
                attached.add(primary)
    return attached, linked


def _content_references(archive: zipfile.ZipFile, members: dict[str, zipfile.ZipInfo], candidates: set[str]) -> set[str]:
    referenced: set[str] = set()
    by_name: dict[str, set[str]] = defaultdict(set)
    for candidate in candidates:
        by_name[PurePosixPath(candidate).name.casefold()].add(candidate)

    for source_path, member in members.items():
        if PurePosixPath(source_path).suffix.lower() not in TEXT_REFERENCE_EXTENSIONS or source_path == "imsmanifest.xml":
            continue
        try:
            text = archive.read(member).decode("utf-8", errors="ignore")
        except (OSError, UnicodeError, zipfile.BadZipFile, RuntimeError):
            continue
        for raw_reference in re.findall(r"(?:href|src|data|poster)\s*=\s*['\"]([^'\"]+)", text, re.IGNORECASE):
            reference = _resolve_reference(source_path, raw_reference)
            if reference in candidates:
                referenced.add(reference)
                continue
            basename = PurePosixPath(reference).name.casefold()
            if len(by_name.get(basename, ())) == 1:
                referenced.update(by_name[basename])
    return referenced


def _resolve_reference(source_path: str, raw_reference: str) -> str:
    parsed = urlsplit(raw_reference)
    path = unquote(parsed.path).replace("\\", "/")
    enforced = re.search(r"/content/enforced/[^/]+/(.+)$", path, re.IGNORECASE)
    if enforced:
        return _normalize_path(enforced.group(1))
    if path.startswith("/") or parsed.scheme or parsed.netloc:
        return _normalize_path(path)
    return _normalize_path(str(PurePosixPath(source_path).parent / path))


def _member_digest(archive: zipfile.ZipFile, member: zipfile.ZipInfo) -> str:
    digest = hashlib.sha256()
    try:
        with archive.open(member) as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(chunk)
        return f"sha256:{digest.hexdigest()}"
    except (OSError, UnicodeError, zipfile.BadZipFile, RuntimeError):
        # Some Brightspace exports contain legacy filenames whose ZIP encoding
        # flag disagrees with the actual name. CRC + size still lets the
        # inventory compare content without failing the entire course scan.
        return f"zipmeta:{member.CRC:08x}:{member.file_size}"


def _finding(location: str, issue: str, severity: Severity, evidence: str, recommendation: str) -> Finding:
    return Finding(
        location=location,
        content_type="Course file",
        issue=issue,
        wcag="Course maintenance",
        severity=severity,
        confidence=Confidence.MANUAL_REVIEW,
        evidence=evidence,
        recommendation=recommendation,
        source=SOURCE,
    )


def _normalize_path(value: str) -> str:
    value = unquote(value).replace("\\", "/").lstrip("/")
    parts = []
    for part in PurePosixPath(value).parts:
        if part in {"", "."}:
            continue
        if part == "..":
            if parts:
                parts.pop()
            continue
        parts.append(part)
    return "/".join(parts)


def _is_hidden(element: ET.Element) -> bool:
    for key, value in element.attrib.items():
        if key.split("}", 1)[-1].lower() in {"isvisible", "visible"} and value.strip().lower() in {"false", "0", "no"}:
            return True
    return False


def _local_name(tag: str) -> str:
    return tag.split("}", 1)[-1]


def _format_size(size: int) -> str:
    return f"{size / (1024 * 1024):.2f} MiB"
