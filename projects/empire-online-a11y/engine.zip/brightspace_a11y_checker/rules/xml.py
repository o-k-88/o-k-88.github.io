﻿from __future__ import annotations

import html
import re
import xml.etree.ElementTree as ET

from ..models import Confidence, CourseItem, Finding, SearchRecord, Severity
from .html import html_search_record_from_markup, scan_html_markup


CONTENT_TAG_HINTS = {
    "assessmentitem",
    "body",
    "content",
    "description",
    "feedback",
    "generalfeedback",
    "intro",
    "introduction",
    "material",
    "mattext",
    "message",
    "prompt",
    "question",
    "questiontext",
    "rubric",
    "text",
    "title",
}


def scan_xml(item: CourseItem) -> list[Finding]:
    raw_xml = item.path.read_text(encoding="utf-8", errors="replace")
    gradebook_findings = _scan_gradebook_weights(item, raw_xml)
    if gradebook_findings is not None:
        return gradebook_findings

    dropbox_findings = _scan_dropbox_folders(item, raw_xml)
    if dropbox_findings is not None:
        return dropbox_findings

    question_findings = _scan_qti_questions(item, raw_xml)
    if question_findings is not None:
        return question_findings

    fragments = _extract_fragments(raw_xml)
    if not fragments:
        return []

    title = _extract_title(raw_xml, item.path.stem)
    markup = _wrap_fragments(title, fragments)
    return scan_html_markup(item, markup)


def xml_search_records(item: CourseItem) -> list[SearchRecord]:
    raw_xml = item.path.read_text(encoding="utf-8", errors="replace")
    if item.path.name.lower() == "grades_d2l.xml":
        return []

    dropbox_records = _dropbox_search_records(item, raw_xml)
    if dropbox_records is not None:
        return dropbox_records

    question_records = _qti_search_records(item, raw_xml)
    if question_records is not None:
        return question_records

    fragments = _extract_fragments(raw_xml)
    if not fragments:
        return []
    title = _extract_title(raw_xml, item.path.stem)
    return [html_search_record_from_markup(item, _wrap_fragments(title, fragments), title=title)]




def _scan_gradebook_weights(item: CourseItem, raw_xml: str) -> list[Finding] | None:
    if item.path.name.lower() != "grades_d2l.xml":
        return None
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return []

    findings: list[Finding] = []
    findings.extend(_grade_association_mismatch_findings(item, root))
    findings.extend(_grade_external_activity_mismatch_findings(item, root))
    for group in _grade_weight_groups(root):
        total = sum(weight for _label, weight in group["items"])
        if abs(total - 100.0) <= 0.1:
            continue
        evidence = "; ".join(f"{label}: {_format_weight(weight)}%" for label, weight in group["items"])
        findings.append(
            Finding(
                location=group["title"],
                content_type="Brightspace gradebook",
                issue="Gradebook weights do not total 100%.",
                wcag="Course quality / gradebook setup",
                severity=Severity.HIGH,
                confidence=Confidence.AUTOMATED,
                evidence=f"Total: {_format_weight(total)}%. {evidence}",
                recommendation="Review the Brightspace gradebook weights. Weighted gradebooks should total 100% so students can understand how the final grade is calculated.",
                suggested_fix="Adjust gradebook category/item weights in Brightspace so the relevant total equals 100%.",
                source="Cartridge Scan",
                location_url=item.location_url,
            )
        )
    return findings






def _grade_external_activity_mismatch_findings(item: CourseItem, root: ET.Element) -> list[Finding]:
    associations = _external_grade_activity_names(item.path.parent)
    if not associations:
        return []
    findings: list[Finding] = []
    seen: set[tuple[str, str]] = set()
    for grade_item in root.iter():
        if _local_name(grade_item.tag).lower() != "item":
            continue
        grade_name = _grade_item_name(grade_item)
        resource_code = grade_item.attrib.get("resource_code", "").strip()
        associated_name = associations.get(resource_code, "")
        if not grade_name or not associated_name:
            continue
        if _normalized_grade_name(grade_name) == _normalized_grade_name(associated_name):
            continue
        key = (_normalized_grade_name(grade_name), _normalized_grade_name(associated_name))
        if key in seen:
            continue
        seen.add(key)
        findings.append(_grade_name_mismatch_finding(item, grade_name, associated_name))
    return findings


def _external_grade_activity_names(root_path) -> dict[str, str]:
    associations: dict[str, str] = {}
    associations.update(_dropbox_grade_activity_names(root_path / "dropbox_d2l.xml"))
    return associations


def _dropbox_grade_activity_names(path) -> dict[str, str]:
    if not path.exists():
        return {}
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError:
        return {}
    associations: dict[str, str] = {}
    for folder in root.iter():
        if _local_name(folder.tag).lower() != "folder":
            continue
        grade_item = folder.attrib.get("grade_item", "").strip()
        name = folder.attrib.get("name", "").strip()
        if grade_item and name:
            associations[grade_item] = html.unescape(name)
    return associations


def _resource_code_title_map(path, wanted_tags: set[str]) -> dict[str, str]:
    if not path.exists():
        return {}
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError:
        return {}
    associations: dict[str, str] = {}
    for element in root.iter():
        if _local_name(element.tag).lower() not in wanted_tags:
            continue
        resource_code = element.attrib.get("resource_code", "").strip()
        title = _element_label(element)
        if resource_code and title:
            associations[resource_code] = title
    return associations


def _grade_name_mismatch_finding(item: CourseItem, grade_name: str, associated_name: str) -> Finding:
    return Finding(
        location=f"Gradebook: {grade_name}",
        content_type="Brightspace gradebook",
        issue="Grade item name does not match its associated activity name.",
        wcag="Course quality / gradebook setup",
        severity=Severity.LOW,
        confidence=Confidence.AUTOMATED,
        evidence=f"Grade item name: {grade_name}; Associated activity: {associated_name}",
        recommendation="Rename the grade item or the associated Brightspace activity so students and instructors see the same name in the gradebook and course activity.",
        suggested_fix=f"Use the same name in both places, for example: {associated_name}",
        source="Cartridge Scan",
        location_url=item.location_url,
    )

def _grade_association_mismatch_findings(item: CourseItem, root: ET.Element) -> list[Finding]:
    findings: list[Finding] = []
    seen: set[tuple[str, str]] = set()
    for element in root.iter():
        if not _looks_like_grade_item_element(element):
            continue
        grade_name = _grade_item_name(element)
        associated_name = _associated_activity_name(element)
        if not grade_name or not associated_name:
            continue
        if _normalized_grade_name(grade_name) == _normalized_grade_name(associated_name):
            continue
        key = (_normalized_grade_name(grade_name), _normalized_grade_name(associated_name))
        if key in seen:
            continue
        seen.add(key)
        findings.append(_grade_name_mismatch_finding(item, grade_name, associated_name))
    return findings


def _looks_like_grade_item_element(element: ET.Element) -> bool:
    name = _normalized_xml_name(element)
    if any(part in name for part in ("gradeitem", "gradeobject", "gradebookitem")):
        return True
    if "item" in name and _grade_item_name(element) and _associated_activity_name(element):
        return True
    return False


def _grade_item_name(element: ET.Element) -> str:
    for key in ("name", "title", "gradeItemName", "grade_item_name"):
        value = element.attrib.get(key, "").strip()
        if value:
            return html.unescape(value)
    for child in list(element):
        child_name = _normalized_xml_name(child)
        if child_name in {"name", "title", "gradeitemname", "gradeobjectname"} and child.text and child.text.strip():
            return html.unescape(child.text.strip())
    return ""


def _associated_activity_name(element: ET.Element) -> str:
    values: list[str] = []
    for key, value in element.attrib.items():
        if _is_association_name(key) and value.strip():
            values.append(value.strip())
    for child in list(element):
        child_name = _normalized_xml_name(child)
        if _is_association_name(child_name):
            if child.text and child.text.strip():
                values.append(child.text.strip())
            for value in child.attrib.values():
                if value.strip():
                    values.append(value.strip())
    for value in values:
        clean = _extract_associated_activity_title(html.unescape(value))
        if clean:
            return clean
    return ""


def _is_association_name(name: str) -> bool:
    clean = re.sub(r"[^a-z0-9]+", "", _local_name(name).lower())
    return any(token in clean for token in ("associated", "association", "activityname", "assignmentname", "dropboxname", "toolname")) and "id" not in clean


def _extract_associated_activity_title(value: str) -> str:
    clean = re.sub(r"\s+", " ", value).strip()
    if not clean:
        return ""
    quoted = re.search(r'"([^"]+)"', clean)
    if quoted:
        return quoted.group(1).strip()
    patterns = [
        r"associated with (?:the )?(?:assignment|activity|discussion|quiz|survey)\s+(.+)$",
        r"(?:assignment|activity|discussion|quiz|survey)\s*[:\-]\s*(.+)$",
    ]
    for pattern in patterns:
        match = re.search(pattern, clean, flags=re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return clean


def _normalized_grade_name(value: str) -> str:
    clean = html.unescape(value or "").casefold()
    clean = re.sub(r"[^\w]+", " ", clean)
    return re.sub(r"\s+", " ", clean).strip()

def _grade_weight_groups(root: ET.Element) -> list[dict[str, object]]:
    groups: list[dict[str, object]] = []
    seen: set[tuple[str, tuple[tuple[str, float], ...]]] = set()
    for parent in root.iter():
        weighted_children: list[tuple[str, float]] = []
        for child in list(parent):
            if not _looks_like_gradebook_weight_child(child):
                continue
            weight = _explicit_weight(child)
            if weight is None:
                continue
            weighted_children.append((_element_label(child), weight))
        if len(weighted_children) < 2:
            continue
        key_items = tuple((label.casefold(), round(weight, 4)) for label, weight in weighted_children)
        key = (_element_label(parent).casefold(), key_items)
        if key in seen:
            continue
        seen.add(key)
        groups.append({"title": _grade_group_title(parent), "items": weighted_children})
    return groups


def _looks_like_gradebook_weight_child(element: ET.Element) -> bool:
    name = _normalized_xml_name(element)
    if any(part in name for part in ("grade", "category", "item", "object", "folder")):
        return True
    return _explicit_weight(element) is not None and bool(_element_label(element))


def _explicit_weight(element: ET.Element) -> float | None:
    for key, value in element.attrib.items():
        if _is_weight_name(key):
            parsed = _parse_weight(value)
            if parsed is not None:
                return parsed
    for child in list(element):
        if not _is_weight_name(_local_name(child.tag)):
            continue
        parsed = _parse_weight(child.text or "")
        if parsed is not None:
            return parsed
        for value in child.attrib.values():
            parsed = _parse_weight(value)
            if parsed is not None:
                return parsed
    return None


def _is_weight_name(name: str) -> bool:
    clean = re.sub(r"[^a-z0-9]+", "", _local_name(name).lower())
    return "weight" in clean and not any(excluded in clean for excluded in ("weightedgrade", "weightedscore"))


def _parse_weight(value: str) -> float | None:
    match = re.search(r"-?\d+(?:\.\d+)?", value or "")
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _element_label(element: ET.Element) -> str:
    for key in ("name", "title", "label", "text"):
        value = element.attrib.get(key, "").strip()
        if value:
            return html.unescape(value)
    for child in list(element):
        if _local_name(child.tag).lower() in {"name", "title", "label"} and child.text and child.text.strip():
            return html.unescape(child.text.strip())
    return _local_name(element.tag)


def _grade_group_title(parent: ET.Element) -> str:
    label = _element_label(parent)
    if label and label.lower() not in {"grades", "gradebook", "gradebookexport"}:
        return f"Gradebook: {label}"
    return "Gradebook"


def _format_weight(value: float) -> str:
    return f"{value:.2f}".rstrip("0").rstrip(".")

def _scan_dropbox_folders(item: CourseItem, raw_xml: str) -> list[Finding] | None:
    root = _dropbox_root(item, raw_xml)
    if root is None:
        return None

    findings: list[Finding] = []
    for title, fragments in _dropbox_folder_fragments(root):
        findings.extend(scan_html_markup(_dropbox_item(item, title), _wrap_fragments(title, fragments)))
    return findings


def _dropbox_search_records(item: CourseItem, raw_xml: str) -> list[SearchRecord] | None:
    root = _dropbox_root(item, raw_xml)
    if root is None:
        return None

    records: list[SearchRecord] = []
    for title, fragments in _dropbox_folder_fragments(root):
        dropbox_item = _dropbox_item(item, title)
        records.append(html_search_record_from_markup(dropbox_item, _wrap_fragments(title, fragments), title=title))
    return records


def _dropbox_root(item: CourseItem, raw_xml: str) -> ET.Element | None:
    if item.path.name.lower() != "dropbox_d2l.xml":
        return None
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return None
    return root if _local_name(root.tag).lower() == "dropbox" else None


def _dropbox_folder_fragments(root: ET.Element) -> list[tuple[str, list[str]]]:
    records: list[tuple[str, list[str]]] = []
    for folder in root.iter():
        if _local_name(folder.tag).lower() != "folder":
            continue
        title = folder.attrib.get("name", "").strip() or "Assignment"
        fragments: list[str] = []
        for child in folder.iter():
            if _local_name(child.tag).lower() == "text" and child.text:
                _add_fragment(fragments, child.text)
        if fragments:
            records.append((title, fragments))
    return records


def _dropbox_item(item: CourseItem, title: str) -> CourseItem:
    return CourseItem(
        title=title,
        path=item.path,
        content_type="Brightspace assignment instructions",
        location_url=item.location_url,
        content_root=item.content_root,
    )


def _extract_fragments(raw_xml: str) -> list[str]:
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return _fallback_extract_fragments(raw_xml)

    return _extract_fragments_from_element(root)


def _extract_fragments_from_element(root: ET.Element) -> list[str]:
    fragments: list[str] = []
    parent_map = {id(child): parent for parent in root.iter() for child in list(parent)}
    for element in root.iter():
        if _is_content_element(element):
            _add_xml_fragment(fragments, element.text or "", element, parent_map)
            for value in element.attrib.values():
                _add_xml_fragment(fragments, value, element, parent_map)
        _add_xml_fragment(fragments, element.tail or "", element, parent_map)

    return fragments


def _add_xml_fragment(fragments: list[str], value: str, element: ET.Element, parent_map: dict[int, ET.Element]) -> None:
    if _is_feedback_context(element, parent_map) and _is_empty_paragraph_fragment(value):
        return
    _add_fragment(fragments, value)


def _is_feedback_context(element: ET.Element, parent_map: dict[int, ET.Element]) -> bool:
    current: ET.Element | None = element
    while current is not None:
        if "feedback" in _local_name(current.tag).lower():
            return True
        current = parent_map.get(id(current))
    return False


def _is_empty_paragraph_fragment(value: str) -> bool:
    clean = html.unescape(value or "").strip()
    return bool(re.fullmatch(r"<p(?:\s[^>]*)?>\s*</p>", clean, flags=re.IGNORECASE))


def _scan_qti_questions(item: CourseItem, raw_xml: str) -> list[Finding] | None:
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return None

    if not _looks_like_qti(item, root):
        return None

    findings: list[Finding] = []
    question_items = [element for element in root.iter() if _local_name(element.tag).lower() == "item"]
    if not question_items:
        fragments = _extract_fragments_from_element(root)
        if not fragments:
            return []
        title = _extract_question_name_from_element(root) or _extract_title(raw_xml, item.path.stem)
        return scan_html_markup(item, _wrap_fragments(title, fragments))

    assessment_title = _assessment_title(root) or _extract_title(raw_xml, item.path.stem)
    question_locations = _qti_question_locations(root, assessment_title)
    for index, question in enumerate(question_items, start=1):
        fragments = _extract_fragments_from_element(question)
        if not fragments:
            continue
        question_title = _extract_question_name_from_element(question) or f"{assessment_title} question {index}"
        title = _format_question_location(question_title, question_locations.get(id(question), assessment_title))
        findings.extend(scan_html_markup(item, _wrap_fragments(title, fragments)))
    return findings


def _qti_search_records(item: CourseItem, raw_xml: str) -> list[SearchRecord] | None:
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return None

    if not _looks_like_qti(item, root):
        return None

    question_items = [element for element in root.iter() if _local_name(element.tag).lower() == "item"]
    if not question_items:
        fragments = _extract_fragments_from_element(root)
        if not fragments:
            return []
        title = _extract_question_name_from_element(root) or _extract_title(raw_xml, item.path.stem)
        return [html_search_record_from_markup(item, _wrap_fragments(title, fragments), title=title)]

    records: list[SearchRecord] = []
    assessment_title = _assessment_title(root) or _extract_title(raw_xml, item.path.stem)
    question_locations = _qti_question_locations(root, assessment_title)
    for index, question in enumerate(question_items, start=1):
        fragments = _extract_fragments_from_element(question)
        if not fragments:
            continue
        question_title = _extract_question_name_from_element(question) or f"{assessment_title} question {index}"
        title = _format_question_location(question_title, question_locations.get(id(question), assessment_title))
        records.append(html_search_record_from_markup(item, _wrap_fragments(title, fragments), title=title))
    return records


def _looks_like_qti(item: CourseItem, root: ET.Element) -> bool:
    normalized_title = item.title.replace("\\", "/").lower()
    if normalized_title.startswith(("quiz/", "survey/")):
        return True
    names = {_local_name(element.tag).lower() for element in root.iter()}
    return "questestinterop" in names or "assessment" in names and "presentation" in names and "response_lid" in names


def _fallback_extract_fragments(raw_xml: str) -> list[str]:
    cdata = re.findall(r"<!\[CDATA\[(.*?)\]\]>", raw_xml, flags=re.DOTALL)
    escaped_html = re.findall(r"&lt;[^&]+?&gt;.*?&lt;/[^&]+?&gt;", raw_xml, flags=re.DOTALL)
    fragments: list[str] = []
    for value in cdata + escaped_html:
        _add_fragment(fragments, value)
    return fragments


def _add_fragment(fragments: list[str], value: str) -> None:
    clean = value.strip()
    if not clean:
        return
    clean = html.unescape(clean)
    if len(clean) < 3:
        return
    if _looks_like_markup(clean):
        fragments.append(clean)
    elif _looks_like_meaningful_text(clean):
        fragments.append(f"<p>{html.escape(clean)}</p>")


def _wrap_fragments(title: str, fragments: list[str]) -> str:
    body = "\n".join(fragments)
    return f"<!doctype html><html lang=\"en\"><head><title>{html.escape(title)}</title></head><body>{body}</body></html>"


def _extract_title(raw_xml: str, fallback: str) -> str:
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return fallback

    for element in root.iter():
        if _local_name(element.tag) == "title" and element.text and element.text.strip():
            return element.text.strip()
    return fallback


def _extract_question_name(raw_xml: str) -> str:
    try:
        root = ET.fromstring(raw_xml)
    except ET.ParseError:
        return ""

    return _extract_question_name_from_element(root)


def _extract_question_name_from_element(root: ET.Element) -> str:
    candidates: list[str] = []
    for element in root.iter():
        local = _local_name(element.tag).lower()
        if any(token in local for token in ("questiontext", "prompt", "mattext", "description", "text")):
            text = _plain_text_from_xml_value(element.text or "")
            if text:
                candidates.append(text)
    if not candidates:
        return ""
    return _short_question_name(candidates[0])


def _assessment_title(root: ET.Element) -> str:
    for element in root.iter():
        if _local_name(element.tag).lower() == "assessment":
            title = element.attrib.get("title", "").strip()
            if title:
                return title
    return ""


def _qti_question_folders(root: ET.Element, assessment_title: str) -> dict[int, str]:
    folders: dict[int, str] = {}

    def walk(element: ET.Element, current_folder: str) -> None:
        local = _local_name(element.tag).lower()
        next_folder = current_folder
        if local in {"assessment", "objectbank", "section"}:
            title = _element_title(element)
            if title:
                next_folder = title
            elif local == "assessment" and assessment_title:
                next_folder = assessment_title

        if local == "item":
            folders[id(element)] = next_folder

        for child in list(element):
            walk(child, next_folder)

    walk(root, assessment_title)
    return folders


def _qti_question_locations(root: ET.Element, assessment_title: str) -> dict[int, str]:
    locations: dict[int, str] = {}
    base_title = _qti_assessment_base_title(assessment_title)
    base_parts = [base_title] if base_title else []

    def walk_children(parent: ET.Element, path_parts: list[str], section_numbers: list[int]) -> None:
        section_count = 0
        item_count = 0
        for child in list(parent):
            local = _local_name(child.tag).lower()
            if local == "assessment":
                child_base = _qti_assessment_base_title(_element_title(child) or assessment_title)
                walk_children(child, [child_base] if child_base else path_parts, section_numbers)
                continue
            if local in {"objectbank", "section"}:
                section_count += 1
                next_numbers = section_numbers + [section_count]
                section_title = _element_title(child)
                section_label = _section_path_label(next_numbers, section_title)
                walk_children(child, path_parts + [section_label], next_numbers)
                continue
            if local == "item":
                item_count += 1
                question_numbers = section_numbers + [item_count] if section_numbers else [item_count]
                locations[id(child)] = " > ".join(path_parts + [f"Question {_number_path(question_numbers)}"])
                continue
            walk_children(child, path_parts, section_numbers)

    if _local_name(root.tag).lower() == "assessment":
        walk_children(root, base_parts, [])
    else:
        walk_children(root, base_parts, [])
    return locations


def _qti_assessment_base_title(assessment_title: str) -> str:
    title = assessment_title.strip()
    if title.lower() in {"quiz library", "question library", "questiondb", "questions"}:
        return ""
    return title


def _section_path_label(section_numbers: list[int], title: str) -> str:
    kind = "Section" if len(section_numbers) == 1 else "Subsection"
    label = f"{kind} {_number_path(section_numbers)}"
    title = title.strip()
    return f"{label}: {title}" if title else label


def _number_path(values: list[int]) -> str:
    return ".".join(str(value) for value in values)


def _element_title(element: ET.Element) -> str:
    title = element.attrib.get("title", "").strip()
    if title:
        return title
    for child in list(element):
        if _local_name(child.tag).lower() == "title" and child.text and child.text.strip():
            return child.text.strip()
    return ""


def _format_question_location(question_title: str, folder_name: str) -> str:
    folder_name = folder_name.strip()
    question_title = question_title.strip()
    if not folder_name or _normalized_text(folder_name) == _normalized_text(question_title):
        return question_title
    return f"{folder_name}: {question_title}"


def _is_content_element(element: ET.Element) -> bool:
    local = _local_name(element.tag).lower()
    if local in CONTENT_TAG_HINTS:
        return True
    return any(hint in local for hint in ("html", "body", "text", "description", "feedback", "question", "prompt"))


def _looks_like_markup(value: str) -> bool:
    return bool(re.search(r"</?(p|div|span|img|a|ul|ol|li|h[1-6]|figure|figcaption|strong|em|b|i)\b", value, re.IGNORECASE))


def _looks_like_meaningful_text(value: str) -> bool:
    return bool(re.search(r"[A-Za-z]{3,}", value))


def _plain_text_from_xml_value(value: str) -> str:
    clean = html.unescape(value or "")
    clean = re.sub(r"<[^>]+>", " ", clean)
    clean = re.sub(r"\s+", " ", clean).strip()
    return clean


def _short_question_name(value: str) -> str:
    value = re.sub(r"\s+", " ", value).strip()
    if not value:
        return ""
    if len(value) <= 220:
        return value
    match = re.search(r"^(.{80,220}?[?!.])(?:\s|$)", value)
    if match:
        return match.group(1)
    shortened = value[:220].rstrip()
    if " " in shortened:
        shortened = shortened.rsplit(" ", 1)[0]
    return shortened


def _normalized_xml_name(element: ET.Element) -> str:
    return re.sub(r"[^a-z0-9]+", "", _local_name(element.tag).lower())

def _local_name(tag: str) -> str:
    return tag.split("}", 1)[-1]


def _normalized_text(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()






