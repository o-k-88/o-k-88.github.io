from __future__ import annotations

import html
import re
from html.parser import HTMLParser
from urllib.parse import unquote, urlparse

from ..models import Confidence, CourseItem, Finding, SearchRecord, Severity


BRIGHTSPACE_BASE_URL = "https://myclasses.sunyempire.edu/d2l/le/"
BRIGHTSPACE_QUICKLINK_DIALOG_PATH = "/d2l/common/dialogs/quicklink/quicklink.d2l"
COURSE_FILE_EXTENSIONS = {
    ".pdf",
    ".doc",
    ".docx",
    ".ppt",
    ".pptx",
    ".xls",
    ".xlsx",
    ".csv",
    ".rtf",
    ".txt",
    ".zip",
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".svg",
    ".mp3",
    ".mp4",
    ".mov",
    ".wmv",
    ".webm",
}
VIDEO_FILE_EXTENSIONS = {".mp4", ".mov", ".wmv", ".webm", ".m4v"}
VIDEO_DOMAINS = (
    "youtube.com",
    "youtu.be",
    "learn.sunyempire.edu",
    "kaltura.com",
    "vimeo.com",
)
APPROVED_TURNITIN_HELP_URL = "https://help.sunyempire.edu/TDClient/277/Portal/KB/Article/11222/Faculty-TurnItIn-Portal"
VIDEO_DURATION_RE = re.compile(r"\b(?:\d{1,2}:)?\d{1,2}:\d{2}\b")
VIDEO_ACCESS_RE = re.compile(
    r"\b(captioned|captions?|accurate captions?|lacks accurate captions?|transcripts?|descriptive transcripts?|"
    r"subtitulado|subtitulada|subt\u00edtulos?|sin subt\u00edtulos precisos|transcripci\u00f3n|transcripciones|transcripci\u00f3n descriptiva)\b",
    re.IGNORECASE,
)
REQUIRED_TEMPLATE_ASSETS = {
    "/shared/Course File Templates/ESC/_assets/thirdpartylib/bootstrap-4.3.1/css/bootstrap.min.css",
    "/shared/Course File Templates/ESC/_assets/thirdpartylib/fontawesome-free-5.9.0-web/css/all.min.css",
    "/shared/Course File Templates/ESC/_assets/css/styles.min.css",
    "/shared/Course File Templates/ESC/_assets/css/custom.css",
    "/shared/Course File Templates/ESC/_assets/js/screenreadertext_JAG.js",
    "/shared/Course File Templates/ESC/_assets/thirdpartylib/jquery/jquery-3.3.1.slim.min.js",
    "/shared/Course File Templates/ESC/_assets/thirdpartylib/popper-js/popper.min.js",
    "/shared/Course File Templates/ESC/_assets/thirdpartylib/bootstrap-4.3.1/js/bootstrap.min.js",
    "/shared/Course File Templates/ESC/_assets/js/scripts.min.js",
}
URL_RE = re.compile(r"https?://[^\s<>\"]+", re.IGNORECASE)
EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
ENTITY_RE = re.compile(r"&(?:[a-zA-Z][a-zA-Z0-9]+|#[0-9]+|#x[0-9a-fA-F]+);")
REPEATED_NBSP_RE = re.compile(r"(?:&nbsp;|&#160;|&#xA0;){2,}", re.IGNORECASE)
BR_SPACING_RE = re.compile(r"(?:<br\s*/?>\s*){2,}|</(?:p|div|section|article|h[1-6]|ul|ol|table|figure)>\s*<br\s*/?>\s*<(?:p|div|section|article|h[1-6]|ul|ol|table|figure)\b", re.IGNORECASE)
SPANISH_ASSESSMENT_TERM_RE = re.compile(r"\b(examen|prueba|cuestionario)s?\b", re.IGNORECASE)
OLD_UNIVERSITY_NAME_RE = re.compile(r"\bEmpire\s+State\s+College\b", re.IGNORECASE)
ESC_TERM_RE = re.compile(r"(?<![\w.-])(?:esc\.edu|esc)(?![\w.-])", re.IGNORECASE)
ESU_TERM_RE = re.compile(r"\bESU\b", re.IGNORECASE)
MOODLE_TERM_RE = re.compile(r"\bMoodle\b", re.IGNORECASE)
MONTH_NAME_PATTERN = (
    r"Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?|"
    r"Sept?(?:ember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?|"
    r"enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre"
)
SPECIFIC_DATE_RE = re.compile(
    rf"\b(?:"
    rf"(?:{MONTH_NAME_PATTERN})\.?\s+\d{{1,2}}(?:st|nd|rd|th)?(?:,?\s+\d{{4}})?|"
    rf"\d{{1,2}}\s+(?:de\s+)?(?:{MONTH_NAME_PATTERN})\.?(?:\s+(?:de\s+)?\d{{4}})?|"
    rf"\d{{4}}-(?:0?[1-9]|1[0-2])-(?:0?[1-9]|[12]\d|3[01])|"
    rf"(?:0?[1-9]|1[0-2])[/.-](?:0?[1-9]|[12]\d|3[01])(?:[/.-]\d{{2,4}})?"
    rf")\b",
    re.IGNORECASE,
)
DUE_DATE_CONTEXT_RE = re.compile(
    r"\b(due\s+date|due\s*(?::|is\b|on\b|by\b)|deadline|submit(?:ted)?(?:\s+\S+){0,8}\s+by|complete(?:d)?(?:\s+\S+){0,8}\s+by|"
    r"finish(?:ed)?(?:\s+\S+){0,8}\s+by|turn\s+in(?:\s+\S+){0,8}\s+by|must\s+be\s+(?:submitted|completed|posted|received)|"
    r"available\s+(?:from|until|through)|opens?\s+(?:on|at)|closes?\s+(?:on|at)|register\s+by|"
    r"registration\s+(?:begins|opens|ends|closes|deadline)|last\s+day\s+to|"
    r"fecha\s+l[\u00edi]mite|vence|entregar\s+(?:antes\s+de|el|para)|debe\s+entregarse|"
    r"disponible\s+(?:desde|hasta)|abre\s+(?:el|a\s+las)|cierra\s+(?:el|a\s+las)|"
    r"inscripci[\u00f3o]n\s+(?:comienza|abre|termina|cierra)|[\u00fau]ltimo\s+d[\u00edi]a\s+para)\b",
    re.IGNORECASE,
)
BARE_DUE_RE = re.compile(r"\bdue\b", re.IGNORECASE)
NON_DEADLINE_DUE_RE = re.compile(r"\bdue\s+(?:to|process|care|diligence|regard|course)\b", re.IGNORECASE)
UNIVERSITY_EVENT_CONTEXT_RE = re.compile(
    r"\b(university\s+(?:event|calendar|is\s+closed)|campus\s+event|academic\s+calendar|commencement|"
    r"convocation|orientation|workshop|webinar|faculty\s+meeting|student\s+meeting|conference|ceremony|"
    r"classes\s+(?:begin|start|end)|semester\s+(?:begins|starts|ends)|term\s+(?:begins|starts|ends)|"
    r"add/drop|withdrawal\s+deadline|university\s+holiday|spring\s+break|winter\s+break|recess|"
    r"evento\s+(?:universitario|del\s+campus)|calendario\s+acad[\u00e9e]mico|graduaci[\u00f3o]n|"
    r"convocatoria|orientaci[\u00f3o]n|taller|seminario\s+web|reuni[\u00f3o]n|conferencia|ceremonia|"
    r"las\s+clases\s+(?:comienzan|empiezan|terminan)|semestre\s+(?:comienza|empieza|termina)|"
    r"universidad\s+cerrada|feriado\s+universitario|receso)\b",
    re.IGNORECASE,
)
HISTORICAL_DATE_CONTEXT_RE = re.compile(
    r"\b(history|historical|historic|born|died|battle|war|revolution|century|era|reign|treaty|"
    r"occurred|took\s+place|was\s+founded|was\s+published|historia|hist[\u00f3o]rico|naci[\u00f3o]|"
    r"muri[\u00f3o]|batalla|guerra|revoluci[\u00f3o]n|siglo|era|reinado|tratado|ocurri[\u00f3o])\b",
    re.IGNORECASE,
)
REFERENCE_DATE_CONTEXT_RE = re.compile(
    r"\b(references?|bibliography|works\s+cited|doi|retrieved|accessed|vol\.?|pp\.?|et\s+al\.?|"
    r"referencias?|bibliograf[\u00edi]a|consultado|recuperado)\b|https?://|\b[A-Z][A-Za-z'-]+,\s*[A-Z]\.",
    re.IGNORECASE,
)
DATE_CONTEXT_TAGS = {"p", "li", "td", "th", "figcaption", "blockquote", "h1", "h2", "h3", "h4", "h5", "h6"}
WORD_XML_PREFIXES = {"o", "w", "v", "m", "st1"}
WORD_CONDITIONAL_COMMENT_RE = re.compile(r"<!--\s*\[if[^\]]*\b(?:mso|gte\s+mso|lt\s+mso)\b[^\]]*\]", re.IGNORECASE)
ALL_CAPS_WORD_RE = re.compile(r"\b[A-Z\u00C0-\u00D6\u00D8-\u00DE][A-Z0-9\u00C0-\u00D6\u00D8-\u00DE'&-]*\b")
SPANISH_TEXT_RE = re.compile(r"[\u00E1\u00E9\u00ED\u00F3\u00FA\u00FC\u00F1\u00BF\u00A1]|\b(el|la|los|las|un|una|para|con|del|que|este|esta|curso|m(?:o|\u00F3)dulo|estudiante|aprendizaje|tarea|lectura|espa(?:n|\u00F1)ol)\b", re.IGNORECASE)
ALLOWED_ALL_CAPS = {"SUNY", "WCAG", "HTML", "PDF", "DOC", "DOCX", "APA", "URL", "URLs", "LMS", "XML", "QTI", "D2L"}
EMPTY_TAG_RE = re.compile(
    r"<(?P<tag>[a-zA-Z][\w:-]*)(?P<attrs>[^>]*)>\s*</(?P=tag)>",
    re.IGNORECASE,
)
VOID_TAGS = {
    "area",
    "base",
    "br",
    "col",
    "embed",
    "hr",
    "img",
    "input",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr",
}
REQUIRED_TEMPLATE_IMAGE_SRC = "/shared/Course File Templates/ESC/_assets/img/BrightspaceTorchIcon_2024_JAG.svg"
IGNORED_IMAGE_SRC_PARTS = (
    REQUIRED_TEMPLATE_IMAGE_SRC,
)
XML_FIGURE_STYLE = "float: right; width: fit-content; max-width: 40%; box-sizing: border-box; margin: 0.5em 0 0.5em 1em; padding: 0.5em; border: 1px solid;"
XML_IMG_STYLE = "display: block; max-width: 100%; height: auto;"
XML_FIGCAPTION_STYLE = "text-align: left; overflow-wrap: anywhere;"


class Element:
    def __init__(self, tag: str, attrs: dict[str, str], text: str = "", parent: "Element | None" = None) -> None:
        self.tag = tag
        self.attrs = attrs
        self.text = text
        self.parent = parent
        self.children: list[Element] = []
        self.content: list[str | Element] = []


class AccessibilityHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.elements: list[Element] = []
        self._stack: list[Element] = []
        self.text_nodes: list[tuple[str, Element | None]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        element = Element(tag.lower(), {key.lower(): value or "" for key, value in attrs}, parent=self._stack[-1] if self._stack else None)
        if self._stack:
            self._stack[-1].children.append(element)
            self._stack[-1].content.append(element)
        self.elements.append(element)
        self._stack.append(element)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        for index in range(len(self._stack) - 1, -1, -1):
            if self._stack[index].tag == tag:
                del self._stack[index:]
                break

    def handle_data(self, data: str) -> None:
        for element in self._stack:
            element.text += data
        if self._stack:
            self._stack[-1].content.append(data)
        self.text_nodes.append((data, self._stack[-1] if self._stack else None))


def scan_html(item: CourseItem) -> list[Finding]:
    markup = item.path.read_text(encoding="utf-8", errors="replace")
    return scan_html_markup(item, markup)


def html_search_record(item: CourseItem) -> SearchRecord:
    markup = item.path.read_text(encoding="utf-8", errors="replace")
    return html_search_record_from_markup(item, markup)


def html_page_name_from_markup(markup: str) -> str:
    parser = AccessibilityHTMLParser()
    parser.feed(markup)
    return _page_record_name(parser.elements)


def html_search_record_from_markup(item: CourseItem, markup: str, title: str = "") -> SearchRecord:
    parser = AccessibilityHTMLParser()
    parser.feed(markup)
    text = _visible_text(" ".join(data for data, parent in parser.text_nodes if not parent or parent.tag not in {"head", "script", "style", "title"}))
    record_title = title or _first_h2_text(parser.elements) or _first_sentence(text) or _page_record_name(parser.elements)
    return SearchRecord(
        title=record_title or item.title,
        text=text,
        content_type=item.content_type,
        source=item.title,
    )


def scan_html_markup(item: CourseItem, markup: str) -> list[Finding]:
    parser = AccessibilityHTMLParser()
    parser.feed(markup)
    page_name = _page_record_name(parser.elements)

    findings: list[Finding] = []
    findings.extend(_check_images(item, parser.elements, page_name))
    findings.extend(_check_links(item, parser.elements, page_name))
    findings.extend(_check_kaltura_content(item, parser.elements, page_name))
    findings.extend(_check_video_link_descriptions(item, parser.elements, page_name))
    findings.extend(_check_plain_text_urls(item, parser.text_nodes, page_name))
    findings.extend(_check_plain_text_emails(item, parser.text_nodes, page_name))
    findings.extend(_check_manual_lists(item, parser.text_nodes, page_name))
    findings.extend(_check_line_break_spacing(item, markup, page_name))
    findings.extend(_check_institutional_language(item, parser.text_nodes, page_name))
    findings.extend(_check_scheduled_dates(item, parser.elements, parser.text_nodes, page_name))
    findings.extend(_check_all_caps(item, parser.text_nodes, page_name))
    findings.extend(_check_spanish_language_markup(item, parser.elements, parser.text_nodes, page_name))
    findings.extend(_check_language(item, parser.elements, page_name))
    findings.extend(_check_headings(item, parser.elements, page_name))
    findings.extend(_check_titles(item, parser.elements, page_name))
    findings.extend(_check_h1_title_match(item, parser.elements, page_name))
    findings.extend(_check_template_assets(item, parser.elements, page_name))
    findings.extend(_check_word_copy_paste_markup(item, markup, parser.elements, page_name))
    findings.extend(_check_semantic_emphasis(item, parser.elements, page_name))
    findings.extend(_check_blockquotes(item, parser.elements, page_name))
    findings.extend(_check_disallowed_creator_plus(item, parser.elements, page_name))
    findings.extend(_check_span_formatting(item, parser.elements, page_name))
    findings.extend(_check_inline_style_rules(item, parser.elements, page_name))
    findings.extend(_check_tables(item, parser.elements, page_name))
    findings.extend(_check_color_and_style(item, parser.elements, page_name))
    findings.extend(_check_embedded_media(item, parser.elements, page_name))
    findings.extend(_check_figure_captions(item, parser.elements, page_name))
    findings.extend(_check_entities(item, markup, page_name))
    findings.extend(
        _check_empty_tags(
            item,
            markup,
            page_name,
            has_expected_template=_has_expected_template_assets(item, parser.elements),
        )
    )
    findings.extend(_check_underscore_blanks(item, parser.text_nodes, page_name))
    return findings


def _finding(
    item: CourseItem,
    issue: str,
    wcag: str,
    severity: Severity,
    confidence: Confidence,
    evidence: str,
    recommendation: str,
    suggested_fix: str = "",
    location: str = "",
) -> Finding:
    return Finding(
        location=location or item.title,
        content_type=item.content_type,
        issue=issue,
        wcag=wcag,
        severity=severity,
        confidence=confidence,
        evidence=evidence[:500],
        recommendation=recommendation,
        suggested_fix=suggested_fix,
        location_url=item.location_url,
    )


def _attrs(element: Element) -> str:
    parts = [element.tag]
    parts.extend(f'{key}="{html.escape(value)}"' for key, value in element.attrs.items() if value)
    return "<" + " ".join(parts) + ">"


def _tag_with_text(element: Element) -> str:
    text = _visible_text(element.text)
    if text:
        return f"{_attrs(element)}{text}</{element.tag}>"
    return _attrs(element)


def _visible_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _page_record_name(elements: list[Element]) -> str:
    h1_class_text = _first_h1_class_text(elements)
    if h1_class_text:
        return h1_class_text

    titles = [_visible_text(element.text) for element in elements if element.tag == "title"]
    for title in titles:
        if title and not _is_placeholder_title(title):
            return title

    for element in elements:
        if re.fullmatch(r"h[1-6]", element.tag):
            text = _visible_text(element.text)
            if text and not _is_placeholder_title(text):
                return text

    for element in elements:
        if element.tag == "body":
            sentence = _first_sentence(element.text)
            if sentence:
                return sentence

    return titles[0] if titles else "Untitled page"


def _first_h1_class_text(elements: list[Element]) -> str:
    for element in elements:
        if element.tag == "h1" and element.attrs.get("class"):
            text = _visible_text(element.text)
            if text:
                return text
    return ""


def _first_h2_text(elements: list[Element]) -> str:
    for element in elements:
        if element.tag == "h2":
            text = _visible_text(element.text)
            if text:
                return text
    return ""


def _first_sentence(text: str) -> str:
    clean = _visible_text(text)
    if not clean:
        return ""
    match = re.search(r"^(.{1,160}?[.!?])(?:\s|$)", clean)
    if match:
        return match.group(1)
    return clean[:160]


def _check_images(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    quiz_or_survey_xml = _is_quiz_or_survey_xml(item)
    described_quiz_image_keys = _described_image_keys(elements) if quiz_or_survey_xml else set()
    for element in elements:
        if element.tag != "img":
            continue
        if _is_ignored_template_image(element):
            continue
        alt = element.attrs.get("alt")
        if alt is None:
            if quiz_or_survey_xml and _image_src_key(element) in described_quiz_image_keys:
                continue
            src = element.attrs.get("src", "")
            suggested_alt = _suggest_alt_text(element)
            findings.append(
                _finding(
                    item,
                    "Image alternative text is missing or too short.",
                    "1.1.1 Non-text Content",
                    Severity.HIGH,
                    Confidence.AUTOMATED,
                    _attrs(element),
                    "Add an alt attribute that communicates the instructional purpose of the image, or use alt=\"\" only when the image is decorative.",
                    f'<img src="{html.escape(src)}" alt="{html.escape(suggested_alt)}">',
                    location=page_name,
                )
            )
        elif not alt.strip() and not _looks_decorative(element):
            if quiz_or_survey_xml and _image_src_key(element) in described_quiz_image_keys:
                continue
            suggested_alt = _suggest_alt_text(element)
            findings.append(
                _finding(
                    item,
                    "Image alternative text is missing or too short.",
                    "1.1.1 Non-text Content",
                    Severity.MEDIUM,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "Confirm whether the image is decorative. If it teaches content or supports an activity, replace the empty alt text with a meaningful description.",
                    f'<img src="{html.escape(element.attrs.get("src", ""))}" alt="{html.escape(suggested_alt)}">',
                    location=page_name,
                )
            )
        elif alt.strip() and len(_visible_text(alt).split()) < 4 and not _looks_decorative(element) and not _is_latex_image(element):
            suggested_alt = _suggest_alt_text(element)
            findings.append(
                _finding(
                    item,
                    "Image alternative text may be too short.",
                    "1.1.1 Non-text Content",
                    Severity.MEDIUM,
                    Confidence.MANUAL_REVIEW,
                    f'alt="{alt}"',
                    "Review alt text shorter than four words. If the image is instructional, use enough words to communicate its purpose or meaning.",
                    f'<img src="{html.escape(element.attrs.get("src", ""))}" alt="{html.escape(suggested_alt)}">',
                    location=page_name,
                )
            )
        if _is_latex_image(element) or quiz_or_survey_xml:
            continue
        if _uses_xml_figure_pattern(item):
            if not _has_xml_figure_pattern(element, elements):
                findings.append(
                    _finding(
                        item,
                        "XML image is not using the expected styled figure pattern.",
                        "1.1.1 Non-text Content; 1.3.1 Info and Relationships",
                        Severity.LOW,
                        Confidence.MANUAL_REVIEW,
                        _attrs(element),
                        "Use the XML content figure pattern with the approved inline figure style, image width, and a figcaption.",
                        _xml_figure_fix(item, element, elements),
                        location=page_name,
                    )
                )
        elif not _has_figure_with_caption(element, elements):
            findings.append(
                _finding(
                    item,
                    "Image is not wrapped in a simple figure with figcaption.",
                    "1.1.1 Non-text Content; 1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "Replace the entire image block, including any enclosing <p> and </p> tags, with the suggested <figure> code. Do not paste the figure inside paragraph tags. Keep the full image src, meaningful alt text, and visible caption.",
                    _html_figure_fix(item, element, elements),
                    location=page_name,
                )
            )
    return findings


def _check_figure_captions(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    if _is_quiz_or_survey_xml(item):
        return findings
    for element in elements:
        if element.tag != "figure":
            continue
        if _figure_contains_latex_image(element, elements):
            continue
        if _figure_needs_xml_pattern(item, element, elements):
            continue
        has_caption = any(candidate.tag == "figcaption" and _is_descendant_of(candidate, element) for candidate in elements)
        if not has_caption:
            suggested_fix = _html_figure_fix(item, _first_descendant(element, "img"), elements)
            recommendation = "Replace the complete existing figure or image paragraph with the suggested code. Do not paste the <figure> inside enclosing <p> tags. Replace the caption text with the visible caption students should see."
            if _uses_xml_figure_pattern(item):
                suggested_fix = (
                    f'<figure style="{XML_FIGURE_STYLE}">\n'
                    f'  <img src="[Brightspace image URL]" alt="[Describe the image]" style="{XML_IMG_STYLE}">\n'
                    f'  <figcaption style="{XML_FIGCAPTION_STYLE}">[Image citation]</figcaption>\n'
                    "</figure>"
                )
                recommendation = "Add a <figcaption> inside the styled XML <figure> pattern."
            findings.append(
                _finding(
                    item,
                    "Figure is missing a figcaption.",
                    "1.1.1 Non-text Content; 1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.AUTOMATED,
                    _tag_with_text(element),
                    recommendation,
                    suggested_fix,
                    location=page_name,
                )
            )
    return findings

def _described_image_keys(elements: list[Element]) -> set[str]:
    keys: set[str] = set()
    for element in elements:
        if element.tag != "img":
            continue
        alt = _visible_text(element.attrs.get("alt", ""))
        if len(alt.split()) >= 4:
            key = _image_src_key(element)
            if key:
                keys.add(key)
    return keys


def _image_src_key(element: Element) -> str:
    src = unquote(element.attrs.get("src", "")).replace("\\", "/").lower()
    if not src:
        return ""
    filename = src.rsplit("/", 1)[-1]
    if filename:
        return filename
    return src

def _looks_decorative(element: Element) -> bool:
    role = element.attrs.get("role", "").lower()
    aria_hidden = element.attrs.get("aria-hidden", "").lower()
    class_name = element.attrs.get("class", "").lower()
    return role == "presentation" or aria_hidden == "true" or "decorative" in class_name


def _is_ignored_template_image(element: Element) -> bool:
    src = element.attrs.get("src", "")
    return any(part in src for part in IGNORED_IMAGE_SRC_PARTS)


def _is_latex_image(element: Element) -> bool:
    if element.tag != "img":
        return False
    attr_text = " ".join(f"{key} {value}" for key, value in element.attrs.items()).lower()
    if any(token in attr_text for token in ("latex", "mathjax", "mathml", "wiris", "equation", "equatio")):
        return True
    alt = element.attrs.get("alt", "") or element.attrs.get("title", "") or element.attrs.get("aria-label", "")
    return bool(re.search(r"(\\\(|\\\[|\\frac|\\sqrt|\\begin\{|\\sum|\\int|\$[^$]+\$)", alt))


def _figure_contains_latex_image(figure: Element, elements: list[Element]) -> bool:
    return any(candidate.tag == "img" and _is_descendant_of(candidate, figure) and _is_latex_image(candidate) for candidate in elements)


def _uses_xml_figure_pattern(item: CourseItem) -> bool:
    if _is_quiz_or_survey_xml(item):
        return False
    return item.content_type in {
        "Brightspace XML content",
        "Brightspace assignment instructions",
        "Brightspace module intro metadata",
    }


def _suggest_alt_text(element: Element) -> str:
    existing = _visible_text(element.attrs.get("alt", ""))
    if existing and len(existing.split()) >= 4:
        return existing

    for attr in ("title", "aria-label"):
        value = _visible_text(element.attrs.get(attr, ""))
        if value:
            return value

    src = element.attrs.get("src", "")
    filename = src.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    stem = filename.rsplit(".", 1)[0]
    words = re.sub(r"[-_]+", " ", stem)
    words = re.sub(r"\b(img|image|photo|pic|figure|diagram)\b", "", words, flags=re.IGNORECASE)
    words = _visible_text(words)
    if words:
        return f"Review: {words}"
    return "Describe the instructional purpose of this image"


def _has_figure_with_caption(element: Element, elements: list[Element]) -> bool:
    parent = element.parent
    while parent:
        if parent.tag == "figure":
            return any(candidate.tag == "figcaption" and _is_descendant_of(candidate, parent) for candidate in elements)
        parent = parent.parent
    return False


def _has_xml_figure_pattern(element: Element, elements: list[Element]) -> bool:
    figure = _nearest_ancestor(element, "figure")
    if not figure:
        return False
    figcaptions = [candidate for candidate in elements if candidate.tag == "figcaption" and _is_descendant_of(candidate, figure)]
    if not figcaptions:
        return False
    return (
        _figure_style_matches_xml_pattern(figure.attrs.get("style", ""))
        and _img_attrs_match_xml_pattern(element)
        and any(_figcaption_attrs_match_xml_pattern(caption) for caption in figcaptions)
    )


def _figure_has_xml_figure_pattern(figure: Element, elements: list[Element]) -> bool:
    return any(candidate.tag == "img" and _is_descendant_of(candidate, figure) and _has_xml_figure_pattern(candidate, elements) for candidate in elements)


def _figure_needs_xml_pattern(item: CourseItem, figure: Element, elements: list[Element]) -> bool:
    if not _uses_xml_figure_pattern(item) or figure.tag != "figure":
        return False
    return any(
        candidate.tag == "img"
        and _is_descendant_of(candidate, figure)
        and not _is_latex_image(candidate)
        and not _has_xml_figure_pattern(candidate, elements)
        for candidate in elements
    )


def _is_inside_replaced_xml_figure(item: CourseItem, element: Element, elements: list[Element]) -> bool:
    figure = element if element.tag == "figure" else _nearest_ancestor(element, "figure")
    return bool(figure and _figure_needs_xml_pattern(item, figure, elements))


def _is_approved_xml_inline_figure_style(item: CourseItem, element: Element, elements: list[Element]) -> bool:
    if not _uses_xml_figure_pattern(item):
        return False
    if element.tag == "img":
        return _has_xml_figure_pattern(element, elements)
    if element.tag == "figure":
        return _figure_has_xml_figure_pattern(element, elements)
    return False


def _nearest_ancestor(element: Element, tag: str) -> Element | None:
    parent = element.parent
    while parent:
        if parent.tag == tag:
            return parent
        parent = parent.parent
    return None


def _xml_figure_fix(item: CourseItem, element: Element, elements: list[Element]) -> str:
    src = _xml_image_src(item, element.attrs.get("src", "image-path.jpg"))
    alt = _decode_embedded_entities(_suggest_alt_text(element))
    caption = _xml_caption_markup(element, elements) or "[Image citation]"
    return (
        f'<figure style="{XML_FIGURE_STYLE}">\n'
        f'  <img src="{_escape_double_quoted_attr(src)}" alt="{_escape_double_quoted_attr(alt)}" style="{XML_IMG_STYLE}">\n'
        f'  <figcaption style="{XML_FIGCAPTION_STYLE}">{caption}</figcaption>\n'
        "</figure>"
    )

def _html_figure_fix(item: CourseItem, element: Element | None, elements: list[Element]) -> str:
    src = "image-path.jpg"
    alt = "Describe the instructional purpose of this image"
    caption = "Write the image caption here."
    if element is not None:
        src = _xml_image_src(item, element.attrs.get("src", src) or src)
        alt = _suggest_alt_text(element)
        caption = _html_caption_text(element, elements) or caption
    return (
        "<figure>\n"
        f'  <img src="{html.escape(src)}" alt="{html.escape(alt)}">\n'
        f"  <figcaption>{html.escape(caption)}</figcaption>\n"
        "</figure>"
    )

def _html_caption_text(element: Element, elements: list[Element]) -> str:
    figure = _nearest_ancestor(element, "figure")
    if not figure:
        return ""
    for candidate in elements:
        if candidate.tag == "figcaption" and _is_descendant_of(candidate, figure):
            return _visible_text(candidate.text)
    return ""


def _first_descendant(element: Element, tag: str) -> Element | None:
    for child in element.children:
        if child.tag == tag:
            return child
        descendant = _first_descendant(child, tag)
        if descendant is not None:
            return descendant
    return None


def _xml_image_src(item: CourseItem, src: str) -> str:
    src = _decode_embedded_entities(src)
    if src.startswith("/content/") or re.match(r"^[a-z][a-z0-9+.-]*:", src, flags=re.IGNORECASE):
        return src
    if item.content_root:
        return item.content_root + src.lstrip("/")
    return src


def _xml_caption_markup(element: Element, elements: list[Element]) -> str:
    figure = _nearest_ancestor(element, "figure")
    if not figure:
        return ""
    for candidate in elements:
        if candidate.tag == "figcaption" and _is_descendant_of(candidate, figure):
            return _clean_xml_caption_inner_html(candidate)
    return ""


def _clean_xml_caption_inner_html(element: Element) -> str:
    return "".join(_clean_xml_caption_part(part) for part in element.content).strip()


def _clean_xml_caption_part(part: str | Element) -> str:
    if isinstance(part, str):
        return html.escape(_decode_embedded_entities(part))
    inner = _clean_xml_caption_inner_html(part)
    if part.tag in {"p", "div"} or (part.tag == "span" and not _has_language_attribute(part)):
        return inner
    if part.tag == "br":
        return "<br>"
    attrs = "".join(
        f' {key}="{_escape_double_quoted_attr(_decode_embedded_entities(value))}"'
        for key, value in part.attrs.items()
        if value and key not in {"style", "class"}
    )
    return f"<{part.tag}{attrs}>{inner}</{part.tag}>"


def _decode_embedded_entities(value: str) -> str:
    decoded = value
    for _ in range(3):
        next_value = html.unescape(decoded)
        if next_value == decoded:
            break
        decoded = next_value
    return decoded


def _escape_double_quoted_attr(value: str) -> str:
    return html.escape(value, quote=False).replace('"', "&quot;")


def _style_map(style: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for declaration in style.split(";"):
        if ":" not in declaration:
            continue
        property_name, value = declaration.split(":", 1)
        values[property_name.strip().lower()] = re.sub(r"\s+", " ", value.strip().lower())
    return values


def _figure_style_matches_xml_pattern(style: str) -> bool:
    values = _style_map(style)
    return (
        values.get("float") == "right"
        and values.get("width") == "fit-content"
        and values.get("max-width") == "40%"
        and values.get("box-sizing") == "border-box"
        and values.get("margin") == "0.5em 0 0.5em 1em"
        and values.get("padding") == "0.5em"
        and values.get("border") == "1px solid"
    )


def _img_attrs_match_xml_pattern(element: Element) -> bool:
    values = _style_map(element.attrs.get("style", ""))
    return (
        values.get("display") == "block"
        and values.get("max-width") == "100%"
        and values.get("height") == "auto"
    )


def _figcaption_attrs_match_xml_pattern(element: Element) -> bool:
    values = _style_map(element.attrs.get("style", ""))
    return values.get("text-align") == "left" and values.get("overflow-wrap") == "anywhere"


def _is_descendant_of(element: Element, ancestor: Element) -> bool:
    parent = element.parent
    while parent:
        if parent is ancestor:
            return True
        parent = parent.parent
    return False


def _check_links(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for element in elements:
        if element.tag != "a":
            continue
        text = _visible_text(element.text).lower()
        href = element.attrs.get("href", "")
        target = element.attrs.get("target", "").lower()
        if _is_turnitin_reference(href, text) and not _is_approved_turnitin_help_url(href):
            link_text = _visible_text(element.text) or "Faculty Turnitin Portal"
            findings.append(
                _finding(
                    item,
                    "Turnitin help link is not the approved SUNY Empire resource.",
                    "Course support information / link maintenance",
                    Severity.MEDIUM,
                    Confidence.AUTOMATED,
                    f"Link text: {link_text}\nCurrent URL: {href}",
                    "Replace the outdated or incorrect Turnitin help link with the approved SUNY Empire Faculty Turnitin Portal.",
                    f'<a href="{APPROVED_TURNITIN_HELP_URL}" target="_blank">{html.escape(link_text)}</a>',
                    location=page_name,
                )
            )
            continue
        if EMAIL_RE.search(_visible_text(element.text)) and not href.lower().startswith("mailto:"):
            email_address = EMAIL_RE.search(_visible_text(element.text)).group(0)
            findings.append(
                _finding(
                    item,
                    "Email address is not linked with mailto.",
                    "2.4.4 Link Purpose (In Context); Content usability",
                    Severity.LOW,
                    Confidence.AUTOMATED,
                    _tag_with_text(element),
                    "Make visible email addresses mailto links so users can activate the email address directly.",
                    f'<a href="mailto:{html.escape(email_address)}" target="_blank">{html.escape(email_address)}</a>',
                    location=page_name,
                )
            )
        if href.lower().startswith("mailto:"):
            findings.extend(_check_mailto_link(item, element, page_name))
        if _looks_like_url(text):
            issue = "Link text is a long URL."
            recommendation = "Replace visible URL text with descriptive link text that names the resource or action."
            if _looks_like_apa_citation(element.text):
                issue = "Citation link text is a long URL."
                recommendation = "APA 7 may include URLs in references, but review whether the long URL should remain visible or be linked from a descriptive DOI/resource title in course content."
            findings.append(
                _finding(
                    item,
                    issue,
                    "2.4.4 Link Purpose (In Context); 2.4.9 Link Purpose (Link Only)",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    element.text.strip(),
                    recommendation,
                    f'<a href="{html.escape(href)}">Descriptive link text</a>',
                    location=page_name,
                )
            )
        if (
            _is_internal_brightspace_link(href)
            and target == "_blank"
            and not _is_brightspace_quicklink_dialog(href)
            and not _is_internal_course_file_link(href)
        ):
            findings.append(
                _finding(
                    item,
                    "Internal Brightspace course link opens in a new window.",
                    "3.2.5 Change on Request",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "Links that stay inside the Brightspace course should usually open in the same window.",
                    f'<a href="{html.escape(href)}">{html.escape(_visible_text(element.text) or "Link text")}</a>',
                    location=page_name,
                )
            )
        elif _is_external_link(href) and target != "_blank":
            findings.append(
                _finding(
                    item,
                    "External link opens in the same window.",
                    "3.2.5 Change on Request",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "External links should open in a new window and include appropriate screen reader warning text.",
                    f'<a href="{html.escape(href)}" target="_blank">{html.escape(_visible_text(element.text) or "Link text")}</a>',
                    location=page_name,
                )
            )
    return findings


def _check_video_link_descriptions(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for element in elements:
        if element.tag != "a":
            continue
        href = element.attrs.get("href", "")
        if not _is_video_link(href):
            continue
        context = _video_link_context(element)
        has_runtime = bool(VIDEO_DURATION_RE.search(context))
        has_access_note = bool(VIDEO_ACCESS_RE.search(context))
        if has_runtime and has_access_note:
            continue
        missing = []
        if not has_runtime:
            missing.append("runtime")
        if not has_access_note:
            missing.append("caption/transcript status")
        link_text = _visible_text(element.text) or "Video title"
        suggested_fix = _video_link_fix(element, spanish=_looks_like_spanish_context(context) or _ancestor_has_language(element, "es"))
        findings.append(
            _finding(
                item,
                "Video link is missing runtime or captioning description.",
                "1.2.2 Captions (Prerecorded); 1.2.3 Audio Description or Media Alternative; 2.4.4 Link Purpose",
                Severity.MEDIUM,
                Confidence.MANUAL_REVIEW,
                f"Link text: {link_text}\\nURL: {href}\\nMissing: {', '.join(missing)}\\nNearby text: {_visible_text(context)}",
                "Add nearby video guidance that includes the runtime and whether the video is captioned, lacks accurate captions, or has a transcript/descriptive transcript. The note may be in English or Spanish.",
                suggested_fix,
                location=page_name,
            )
        )
    return findings


def _check_kaltura_content(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    urls: list[str] = []
    seen: set[str] = set()
    for element in elements:
        if element.tag == "a":
            url = element.attrs.get("href", "").strip()
        elif element.tag in {"iframe", "embed"}:
            url = element.attrs.get("src", "").strip()
        else:
            continue
        if not _is_kaltura_url(url) or url in seen:
            continue
        seen.add(url)
        urls.append(url)
    if not urls:
        return []
    return [
        _finding(
            item,
            "Page contains Kaltura-hosted media.",
            "Course media review",
            Severity.LOW,
            Confidence.MANUAL_REVIEW,
            "Kaltura URL(s):\n" + "\n".join(urls),
            "Review the Kaltura link or embedded player and confirm the media remains available, uses accurate captions, and includes the required runtime and caption/transcript guidance.",
            location=page_name,
        )
    ]


def _is_kaltura_url(url: str) -> bool:
    if not url:
        return False
    host = urlparse(html.unescape(url)).netloc.lower().split(":", 1)[0]
    return "kaltura" in host


def _is_turnitin_reference(href: str, link_text: str) -> bool:
    return "turnitin" in unquote(href).lower().replace("-", "") or "turnitin" in link_text.replace(" ", "").replace("-", "")


def _is_approved_turnitin_help_url(href: str) -> bool:
    parsed = urlparse(html.unescape(href.strip()))
    approved = urlparse(APPROVED_TURNITIN_HELP_URL)
    return (
        parsed.scheme.lower() == approved.scheme
        and parsed.netloc.lower() == approved.netloc.lower()
        and parsed.path.rstrip("/").lower() == approved.path.rstrip("/").lower()
    )


def _is_video_link(href: str) -> bool:
    clean = href.strip()
    if not clean:
        return False
    parsed = urlparse(clean)
    host = parsed.netloc.lower()
    path = unquote(parsed.path).lower()
    if any(domain in host for domain in VIDEO_DOMAINS):
        return True
    return any(path.endswith(extension) for extension in VIDEO_FILE_EXTENSIONS)


def _video_link_context(element: Element) -> str:
    block = _nearest_block_ancestor(element) or element
    parts = [_visible_text(block.text)]
    if block.tag == "p":
        next_paragraph = _next_sibling_with_tag(block, "p")
        if next_paragraph is not None:
            parts.append(_visible_text(next_paragraph.text))
    return " ".join(part for part in parts if part)


def _nearest_block_ancestor(element: Element) -> Element | None:
    current: Element | None = element
    while current is not None:
        if current.tag in {"p", "li", "td", "th", "blockquote", "figcaption"}:
            return current
        current = current.parent
    return None


def _next_sibling_with_tag(element: Element, tag: str) -> Element | None:
    if element.parent is None:
        return None
    siblings = element.parent.children
    try:
        index = siblings.index(element)
    except ValueError:
        return None
    for sibling in siblings[index + 1:]:
        if sibling.tag == tag:
            return sibling
        if _visible_text(sibling.text):
            return None
    return None


def _looks_like_spanish_context(text: str) -> bool:
    return bool(SPANISH_TEXT_RE.search(text))


def _video_link_fix(element: Element, *, spanish: bool) -> str:
    href = element.attrs.get("href", "")
    text = _visible_text(element.text) or "Video title"
    if spanish:
        note = "(MM:SS, subtitulado)"
    else:
        note = "(MM:SS, captioned)"
    return f'<a href="{html.escape(href)}" target="_blank">{html.escape(text)} (opens in a new window)</a> {note}'

def _check_mailto_link(item: CourseItem, element: Element, page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    href = element.attrs.get("href", "")
    target = element.attrs.get("target", "").lower()
    email_address = _email_from_mailto(href) or EMAIL_RE.search(_visible_text(element.text) or "")
    clean_email = email_address.group(0) if hasattr(email_address, "group") else email_address
    clean_email = clean_email or "name@example.edu"
    link_text = _visible_text(element.text) or clean_email

    if re.match(r"mailto:\s+", href, flags=re.IGNORECASE):
        findings.append(
            _finding(
                item,
                "Mailto link has a space after the colon.",
                "2.4.4 Link Purpose (In Context); Content usability",
                Severity.LOW,
                Confidence.AUTOMATED,
                _attrs(element),
                "Remove spaces after mailto: so the email address starts directly after the colon.",
                f'<a href="mailto:{html.escape(clean_email)}" target="_blank">{html.escape(link_text)}</a>',
                location=page_name,
            )
        )

    if target != "_blank":
        findings.append(
            _finding(
                item,
                "Mailto link does not open in a new window.",
                "3.2.5 Change on Request",
                Severity.LOW,
                Confidence.MANUAL_REVIEW,
                _attrs(element),
                "Mailto links should open externally in a new window.",
                f'<a href="mailto:{html.escape(clean_email)}" target="_blank">{html.escape(link_text)}</a>',
                location=page_name,
            )
        )
    return findings


def _check_plain_text_urls(item: CourseItem, text_nodes: list[tuple[str, Element | None]], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for text, parent in text_nodes:
        if parent and parent.tag in {"a", "script", "style"}:
            continue
        for match in URL_RE.findall(text):
            issue = "Long URL appears as plain text."
            recommendation = "Convert the URL to a descriptive link with meaningful link text."
            if _looks_like_apa_citation(text):
                issue = "Citation contains a long URL."
                recommendation = "APA 7 citations may include visible URLs, but confirm the reference is intentionally formatted this way and that surrounding link text remains understandable."
            findings.append(
                _finding(
                    item,
                    issue,
                    "2.4.4 Link Purpose (In Context); 2.4.9 Link Purpose (Link Only)",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    match,
                    recommendation,
                    f'<a href="{html.escape(match)}">Descriptive link text</a>',
                    location=page_name,
                )
            )
    return findings


def _check_plain_text_emails(item: CourseItem, text_nodes: list[tuple[str, Element | None]], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for text, parent in text_nodes:
        if parent and parent.tag in {"a", "script", "style"}:
            continue
        for match in EMAIL_RE.finditer(text):
            email_address = match.group(0)
            findings.append(
                _finding(
                    item,
                    "Email address is not linked with mailto.",
                    "2.4.4 Link Purpose (In Context); Content usability",
                    Severity.LOW,
                    Confidence.AUTOMATED,
                    _text_match_evidence(text, match.start(), match.end()),
                    "Make visible email addresses mailto links so users can activate the email address directly.",
                    f'<a href="mailto:{html.escape(email_address)}" target="_blank">{html.escape(email_address)}</a>',
                    location=page_name,
                )
            )
    return findings


def _check_manual_lists(item: CourseItem, text_nodes: list[tuple[str, Element | None]], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    seen: set[tuple[str, str]] = set()
    for text, parent in text_nodes:
        if not text.strip() or _inside_semantic_list(parent):
            continue
        if _looks_like_manual_bulleted_list(text):
            key = ("bullets", _visible_text(text))
            if key not in seen:
                seen.add(key)
                findings.append(
                    _finding(
                        item,
                        "Text appears to use manual bullet marks instead of a semantic list.",
                        "1.3.1 Info and Relationships",
                        Severity.MEDIUM,
                        Confidence.MANUAL_REVIEW,
                        _visible_text(text),
                        "Use a semantic unordered list with <ul> and <li> items instead of typing minus signs or asterisks as bullets.",
                        "<ul>\\n  <li>First item</li>\\n  <li>Second item</li>\\n</ul>",
                        location=page_name,
                    )
                )
        if _looks_like_manual_numbered_list(text):
            key = ("numbered", _visible_text(text))
            if key not in seen:
                seen.add(key)
                findings.append(
                    _finding(
                        item,
                        "Text appears to use manual numbering instead of a semantic list.",
                        "1.3.1 Info and Relationships",
                        Severity.MEDIUM,
                        Confidence.MANUAL_REVIEW,
                        _visible_text(text),
                        "Use a semantic ordered list with <ol> and <li> items instead of manually typing labels such as 1., 2., A., B., 1), or a).",
                        "<ol>\\n  <li>First item</li>\\n  <li>Second item</li>\\n</ol>",
                        location=page_name,
                    )
                )
    return findings



def _check_line_break_spacing(item: CourseItem, markup: str, page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    seen: set[str] = set()
    for match in BR_SPACING_RE.finditer(markup):
        if _match_is_inside_allowed_br_context(markup, match.start()):
            continue
        evidence = _compact_markup_evidence(match.group(0))
        key = evidence.lower()
        if key in seen:
            continue
        seen.add(key)
        findings.append(
            _finding(
                item,
                "Line break tags appear to be used for visual spacing.",
                "1.3.1 Info and Relationships; 1.4.12 Text Spacing",
                Severity.LOW,
                Confidence.MANUAL_REVIEW,
                evidence,
                "Do not use <br> tags to create extra blank space between paragraphs or sections. Use real paragraphs, lists, headings, or approved template spacing instead. Keep <br> only for meaningful line breaks such as mailing addresses, poetry, or lyrics.",
                location=page_name,
            )
        )
    return findings


def _match_is_inside_allowed_br_context(markup: str, position: int) -> bool:
    before = markup[:position].lower()
    for tag in ("address", "pre", "poem"):
        open_index = before.rfind(f"<{tag}")
        close_index = before.rfind(f"</{tag}>")
        if open_index > close_index:
            return True
    return False


def _compact_markup_evidence(markup: str) -> str:
    compact = re.sub(r"\s+", " ", markup).strip()
    return compact[:500]

def _check_institutional_language(item: CourseItem, text_nodes: list[tuple[str, Element | None]], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    seen: set[tuple[str, str]] = set()
    for text, parent in text_nodes:
        if not text.strip() or parent and parent.tag in {"script", "style"}:
            continue
        visible_text = _visible_text(text)
        if not visible_text:
            continue
        findings.extend(_term_findings(item, page_name, visible_text, SPANISH_ASSESSMENT_TERM_RE, "Spanish assessment term may need review.", "Review Spanish assessment terms such as examen, prueba, or cuestionario. Use the current course vocabulary approved for this context.", seen))
        findings.extend(_term_findings(item, page_name, visible_text, OLD_UNIVERSITY_NAME_RE, "Old university name appears in page text.", "Replace Empire State College with the current university name unless the historical name is intentionally required.", seen))
        findings.extend(_term_findings(item, page_name, visible_text, ESC_TERM_RE, "Old ESC abbreviation or domain appears in page text.", "Replace ESC, esc.edu, or related old shorthand with current SUNY Empire naming unless it appears inside a URL.", seen, skip_urls=True))
        findings.extend(_term_findings(item, page_name, visible_text, ESU_TERM_RE, "Unapproved ESU abbreviation appears in page text.", "Replace ESU with the approved university name or abbreviation for SUNY Empire.", seen))
        findings.extend(_term_findings(item, page_name, visible_text, MOODLE_TERM_RE, "Moodle appears in page text.", "Review references to Moodle and update them for the current Brightspace course context unless the reference is intentionally historical or comparative.", seen))
    return findings


def _term_findings(
    item: CourseItem,
    page_name: str,
    text: str,
    pattern: re.Pattern[str],
    issue: str,
    recommendation: str,
    seen: set[tuple[str, str]],
    skip_urls: bool = False,
) -> list[Finding]:
    findings: list[Finding] = []
    for match in pattern.finditer(text):
        if skip_urls and _span_is_inside_plain_text_url(text, match.start(), match.end()):
            continue
        evidence = _text_match_evidence(text, match.start(), match.end())
        key = (issue, evidence.lower())
        if key in seen:
            continue
        seen.add(key)
        findings.append(
            _finding(
                item,
                issue,
                "Content quality / institutional terminology",
                Severity.LOW,
                Confidence.MANUAL_REVIEW,
                evidence,
                recommendation,
                location=page_name,
            )
        )
    return findings


def _check_scheduled_dates(
    item: CourseItem,
    elements: list[Element],
    text_nodes: list[tuple[str, Element | None]],
    page_name: str,
) -> list[Finding]:
    if _is_quiz_or_survey_xml(item):
        return []

    candidates = [_visible_text(element.text) for element in elements if element.tag in DATE_CONTEXT_TAGS]
    candidates.extend(
        _visible_text(text)
        for text, parent in text_nodes
        if parent is None or parent.tag == "body"
    )
    findings: list[Finding] = []
    seen: set[tuple[str, str]] = set()
    for candidate in candidates:
        if not candidate or not SPECIFIC_DATE_RE.search(candidate):
            continue
        for match in SPECIFIC_DATE_RE.finditer(candidate):
            context = _date_context(candidate, match.start(), match.end())
            kind = _scheduled_date_kind(context, match.group(0))
            if not kind:
                continue
            key = (kind, match.group(0).lower(), context.lower())
            if key in seen:
                continue
            seen.add(key)
            if kind == "due":
                recommendation = (
                    "Confirm that this due date is current. Prefer setting assignment and activity dates in Brightspace "
                    "date controls; update or remove fixed dates in reusable page content when they could become stale."
                )
            else:
                recommendation = (
                    "Confirm this university event date against the current academic or university calendar, and update "
                    "or remove the date if the page will be reused in another term."
                )
            findings.append(
                _finding(
                    item,
                    "Specific due date or university event date appears in page text.",
                    "Content quality / date accuracy",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    f"Date: {match.group(0)}\nContext: {context}",
                    recommendation,
                    location=page_name,
                )
            )
    return findings


def _scheduled_date_kind(context: str, date_text: str) -> str:
    if _looks_like_reference_date_context(context):
        return ""
    if DUE_DATE_CONTEXT_RE.search(context):
        return "due"
    if BARE_DUE_RE.search(context) and not NON_DEADLINE_DUE_RE.search(context):
        return "due"
    if not UNIVERSITY_EVENT_CONTEXT_RE.search(context):
        return ""
    if HISTORICAL_DATE_CONTEXT_RE.search(context):
        return ""
    year_match = re.search(r"\b(\d{4})\b", date_text)
    if year_match and int(year_match.group(1)) < 2000:
        return ""
    return "event"


def _looks_like_reference_date_context(context: str) -> bool:
    if REFERENCE_DATE_CONTEXT_RE.search(context):
        return True
    if _looks_like_apa_reference_text(context):
        return True
    return bool(re.search(r"\(\s*[12]\d{3}\s*,\s*(?:" + MONTH_NAME_PATTERN + r")\.?\s+\d{1,2}\s*\)", context, re.IGNORECASE))


def _date_context(text: str, start: int, end: int) -> str:
    if len(text) <= 500:
        return text
    context_start = max(0, start - 180)
    context_end = min(len(text), end + 180)
    return ("..." if context_start else "") + text[context_start:context_end].strip() + ("..." if context_end < len(text) else "")


def _check_all_caps(item: CourseItem, text_nodes: list[tuple[str, Element | None]], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    seen: set[str] = set()
    for text, parent in text_nodes:
        if not text.strip() or parent and parent.tag in {"script", "style", "title"}:
            continue
        for value in _all_caps_phrases(text):
            key = value.lower()
            if key in seen:
                continue
            seen.add(key)
            findings.append(
                _finding(
                    item,
                    "All-caps text may be difficult to read.",
                    "3.1.5 Reading Level; Usability / readability",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    value,
                    "Avoid using all caps for emphasis in sentences or headings because it can be harder to read, especially for people with dyslexia. Use sentence case and semantic emphasis or a callout when needed.",
                    _sentence_case_fix(value),
                    location=page_name,
                )
            )
    return findings


def _all_caps_phrases(text: str) -> list[str]:
    phrases: list[str] = []
    current: list[str] = []
    for token in re.findall(r"[\w\u00C0-\u00FF'&-]+|[^\w\u00C0-\u00FF]+", text):
        if ALL_CAPS_WORD_RE.fullmatch(token) and token not in ALLOWED_ALL_CAPS:
            current.append(token)
            continue
        if token.strip() and current:
            _append_all_caps_phrase(phrases, current)
            current = []
    if current:
        _append_all_caps_phrase(phrases, current)
    return phrases


def _append_all_caps_phrase(phrases: list[str], words: list[str]) -> None:
    if len(words) >= 5:
        phrases.append(" ".join(words))

def _sentence_case_fix(value: str) -> str:
    lower = value.lower()
    return lower[:1].upper() + lower[1:]


def _check_spanish_language_markup(item: CourseItem, elements: list[Element], text_nodes: list[tuple[str, Element | None]], page_name: str) -> list[Finding]:
    if _page_language_starts_with(elements, "es"):
        return []
    findings: list[Finding] = []
    seen: set[str] = set()
    for text, parent in text_nodes:
        if not text.strip() or parent is None or parent.tag in {"head", "script", "style", "title"}:
            continue
        visible_text = _visible_text(text)
        if len(visible_text) < 12 or not SPANISH_TEXT_RE.search(visible_text):
            continue
        if _ancestor_has_language(parent, "es"):
            continue
        key = visible_text.lower()
        if key in seen:
            continue
        seen.add(key)
        findings.append(
            _finding(
                item,
                'Spanish text is missing lang="es" markup.',
                "3.1.2 Language of Parts",
                Severity.MEDIUM,
                Confidence.MANUAL_REVIEW,
                visible_text,
                'Wrap Spanish text in <span lang="es">...</span> unless the whole page is correctly marked as Spanish with <html lang="es">.',
                f'<span lang="es">{html.escape(visible_text)}</span>',
                location=page_name,
            )
        )
    return findings


def _page_language_starts_with(elements: list[Element], language: str) -> bool:
    for element in elements:
        if element.tag == "html":
            value = (element.attrs.get("lang") or element.attrs.get("xml:lang") or "").lower()
            return value == language or value.startswith(language + "-")
    return False


def _ancestor_has_language(element: Element, language: str) -> bool:
    current: Element | None = element
    while current is not None:
        value = (current.attrs.get("lang") or current.attrs.get("xml:lang") or "").lower()
        if value == language or value.startswith(language + "-"):
            return True
        current = current.parent
    return False


def _check_headings(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    if item.content_type != "HTML content page":
        return []
    findings: list[Finding] = []
    heading_levels = [int(element.tag[1]) for element in elements if re.fullmatch(r"h[1-6]", element.tag)]

    if not heading_levels:
        findings.append(
            _finding(
                item,
                "Page has no headings.",
                "1.3.1 Info and Relationships; 2.4.6 Headings and Labels",
                Severity.MEDIUM,
                Confidence.AUTOMATED,
                "No h1-h6 elements found.",
                "Use meaningful heading levels to expose page structure to screen reader and keyboard users.",
                location=page_name,
            )
        )
        return findings

    if heading_levels[0] not in {1, 2}:
        findings.append(
            _finding(
                item,
                "First content heading starts too deep.",
                "1.3.1 Info and Relationships; 2.4.6 Headings and Labels",
                Severity.LOW,
                Confidence.MANUAL_REVIEW,
                f"First heading level: H{heading_levels[0]}",
                "Brightspace supplies the page title as H1, so exported page bodies may begin with H2. Review content that begins below H2 and adjust heading levels if the structure is skipped.",
                location=page_name,
            )
        )

    previous = heading_levels[0]
    for level in heading_levels[1:]:
        if level > previous + 1:
            findings.append(
                _finding(
                    item,
                    "Heading levels appear to skip.",
                    "1.3.1 Info and Relationships; 2.4.6 Headings and Labels",
                    Severity.MEDIUM,
                    Confidence.AUTOMATED,
                    f"H{previous} followed by H{level}",
                    "Use headings in sequence so the outline reflects the visual and instructional structure.",
                    location=page_name,
                )
            )
            break
        previous = level

    return findings


def _check_titles(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    titles = [_visible_text(element.text) for element in elements if element.tag == "title"]
    if not titles:
        findings.append(
            _finding(
                item,
                "Page is missing a title element.",
                "2.4.2 Page Titled",
                Severity.MEDIUM,
                Confidence.AUTOMATED,
                "No <title> element found.",
                "Add a meaningful <title> that matches or clearly identifies the Brightspace page.",
                location=page_name,
            )
        )
    for title in titles:
        if _is_placeholder_title(title):
            findings.append(
                _finding(
                    item,
                    "Page title appears to be a placeholder.",
                    "2.4.2 Page Titled",
                    Severity.MEDIUM,
                    Confidence.AUTOMATED,
                    f"<title>{title}</title>",
                    "Replace placeholder title text with the actual page title.",
                    "<title>Actual page title</title>",
                    location=page_name,
                )
            )
    return findings


def _check_h1_title_match(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    h1_text = _first_h1_class_text(elements)
    if not h1_text:
        return []
    title = next((_visible_text(element.text) for element in elements if element.tag == "title"), "")
    if not title or _is_placeholder_title(title) or _normalized_text(title) == _normalized_text(h1_text):
        return []
    return [
        _finding(
            item,
            "H1 text does not match the page title.",
            "2.4.2 Page Titled; 2.4.6 Headings and Labels",
            Severity.LOW,
            Confidence.MANUAL_REVIEW,
            f"Page title: {title}\\nH1 text: {h1_text}",
            "Make the page <title> and visible H1 communicate the same page topic. The evidence lists both mismatched values.",
            f"<title>{html.escape(h1_text)}</title>",
            location=page_name,
        )
    ]


def _check_template_assets(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    if item.content_type not in {"HTML content page", "Brightspace HTML page metadata"}:
        return []
    missing_assets = _missing_template_assets(elements)
    missing_structure = _missing_template_structure(elements)
    if not missing_assets and not missing_structure:
        return []
    evidence_parts = []
    if missing_assets:
        evidence_parts.append("Missing template asset(s): " + ", ".join(missing_assets[:6]))
    if missing_structure:
        evidence_parts.append("Missing template structure: " + ", ".join(missing_structure))
    return [
        _finding(
            item,
            "Page does not use the expected SUNY Empire Bootstrap template.",
            "1.3.1 Info and Relationships; 4.1.2 Name, Role, Value",
            Severity.MEDIUM,
            Confidence.MANUAL_REVIEW,
            " | ".join(evidence_parts),
            "Compare this page with the approved bootstrap.html template and restore missing CSS, JavaScript, and footer structure before reviewing page content.",
            location=page_name,
        )
    ]


def _has_expected_template_assets(item: CourseItem, elements: list[Element]) -> bool:
    if item.content_type not in {"HTML content page", "Brightspace HTML page metadata"}:
        return True
    return not _missing_template_assets(elements)


def _missing_template_assets(elements: list[Element]) -> list[str]:
    asset_refs = {
        element.attrs.get("href", "") for element in elements if element.tag == "link"
    } | {
        element.attrs.get("src", "") for element in elements if element.tag == "script"
    }
    return sorted(asset for asset in REQUIRED_TEMPLATE_ASSETS if asset not in asset_refs)


def _missing_template_structure(elements: list[Element]) -> list[str]:
    image_sources = {element.attrs.get("src", "") for element in elements if element.tag == "img"}
    if REQUIRED_TEMPLATE_IMAGE_SRC not in image_sources:
        return ["standard footer SUNY Empire torch image"]
    return []


def _check_word_copy_paste_markup(
    item: CourseItem,
    markup: str,
    elements: list[Element],
    page_name: str,
) -> list[Finding]:
    evidence: list[str] = []
    for element in elements:
        tag_prefix = element.tag.split(":", 1)[0] if ":" in element.tag else ""
        classes = element.attrs.get("class", "").split()
        style = element.attrs.get("style", "")
        attrs_lower = {key.lower(): value.lower() for key, value in element.attrs.items()}

        if tag_prefix in WORD_XML_PREFIXES:
            _append_unique_word_evidence(evidence, _tag_with_text(element))
        if any(class_name.lower().startswith("mso") for class_name in classes):
            _append_unique_word_evidence(evidence, _tag_with_text(element))
        if re.search(r"(?:^|;)\s*mso-[a-z0-9-]+\s*:", style, re.IGNORECASE):
            _append_unique_word_evidence(evidence, _tag_with_text(element))
        if any(
            (key.startswith("xmlns:") and key.split(":", 1)[1] in WORD_XML_PREFIXES)
            or key.split(":", 1)[0] in WORD_XML_PREFIXES
            for key in attrs_lower
        ):
            _append_unique_word_evidence(evidence, _attrs(element))
        if element.tag == "meta" and "generator" in attrs_lower.get("name", "") and "word" in attrs_lower.get("content", ""):
            _append_unique_word_evidence(evidence, _attrs(element))

        if len(evidence) >= 5:
            break

    if len(evidence) < 5:
        for match in WORD_CONDITIONAL_COMMENT_RE.finditer(markup):
            _append_unique_word_evidence(evidence, re.sub(r"\s+", " ", match.group(0)).strip())
            if len(evidence) >= 5:
                break

    if not evidence:
        return []
    return [
        _finding(
            item,
            "Microsoft Word copy-and-paste markup appears in page HTML.",
            "1.3.1 Info and Relationships; content maintainability",
            Severity.MEDIUM,
            Confidence.AUTOMATED,
            "Word/Office signatures found:\n" + "\n".join(f"- {value}" for value in evidence),
            "Remove Microsoft Word-specific tags, classes, namespaces, conditional comments, and mso- styles. Preserve the visible content, then rebuild headings, lists, tables, links, and emphasis with Brightspace's semantic editor controls or approved template components. Pasting as plain text before reformatting can prevent this markup from returning.",
            location=page_name,
        )
    ]


def _append_unique_word_evidence(evidence: list[str], value: str) -> None:
    compact = re.sub(r"\s+", " ", value).strip()
    if compact and compact not in evidence:
        evidence.append(compact[:220])


def _check_semantic_emphasis(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for element in elements:
        if element.tag in {"b", "strong"} and _is_bold_paragraph_emphasis(element):
            text = _visible_text(element.text) or "Callout Content"
            findings.append(
                _finding(
                    item,
                    "Bold paragraph should use a callout box.",
                    "1.3.1 Info and Relationships; 2.4.6 Headings and Labels",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _tag_with_text(element),
                    "If an entire paragraph is bolded for emphasis, use the Brightspace callout component so the emphasis is structured and easier to scan.",
                    _callout_fix(item, text),
                    location=page_name,
                )
            )
        elif element.tag == "b":
            findings.append(
                _finding(
                    item,
                    "Bold tag used instead of strong.",
                    "1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.AUTOMATED,
                    _tag_with_text(element),
                    "Use <strong> when text has strong importance. Use CSS classes when text is only visually bold.",
                    f"<strong>{html.escape(_visible_text(element.text) or 'Important text')}</strong>",
                    location=page_name,
                )
            )
        elif element.tag == "i":
            findings.append(
                _finding(
                    item,
                    "Italic tag used instead of emphasis.",
                    "1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.AUTOMATED,
                    _tag_with_text(element),
                    "Use <em> when text is emphasized. Use CSS classes when text is only visually italic.",
                    f"<em>{html.escape(_visible_text(element.text) or 'Emphasized text')}</em>",
                    location=page_name,
                )
            )
    return findings


def _is_bold_paragraph_emphasis(element: Element) -> bool:
    parent = element.parent
    if not parent or parent.tag != "p":
        return False
    element_text = _visible_text(element.text)
    parent_text = _visible_text(parent.text)
    if not element_text or _sentence_count(element_text) < 3:
        return False
    return _normalized_text(element_text) == _normalized_text(parent_text)


def _sentence_count(text: str) -> int:
    clean = _visible_text(text)
    if not clean:
        return 0
    return len(re.findall(r"[^.!?]+[.!?](?=\s|$)", clean))


def _callout_fix(item: CourseItem, content: str) -> str:
    escaped_content = html.escape(content)
    if _uses_xml_callout_fix(item):
        return (
            '<div style="background-color: #e7f3fe; border-left: 6px solid #2196F3; padding: 15px; margin: 15px 0; border-radius: 4px; font-family: sans-serif;">\n'
            '  <p style="margin-top: 0; font-weight: bold; color: #0c5460;">\U0001f4a1 Info</p>\n'
            f'  <p style="margin-bottom: 0; color: #1f2d3d;">{escaped_content}</p>\n'
            '</div>'
        )
    return (
        '<div class="d2l-element mceNonEditable" data-idx="3" data-type="noicon" role="section" aria-describedby="d2l-uid-271">\n'
        '<p id="d2l-uid-271" class="sr-only">Callout</p>\n'
        '<div class="card card-standard" data-prop="0|noicon">\n'
        '<div class="card-body">\n'
        '<div class="card-text">\n'
        '<div class="d2l-callout-title" data-prop="1|null">Important</div>\n'
        '<div data-prop="2|null">\n'
        f'<p>{escaped_content}</p>\n'
        '</div>\n'
        '</div>\n'
        '</div>\n'
        '</div>\n'
        '</div>'
    )

def _uses_xml_callout_fix(item: CourseItem) -> bool:
    return item.content_type in {
        "Brightspace XML content",
        "Brightspace assignment instructions",
        "Brightspace module intro metadata",
    }

def _check_blockquotes(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for element in elements:
        if element.tag != "blockquote":
            continue
        text = _visible_text(element.text) or "Callout Content"
        findings.append(
            _finding(
                item,
                "Blockquote should use a callout box.",
                "1.3.1 Info and Relationships; 2.4.6 Headings and Labels",
                Severity.LOW,
                Confidence.MANUAL_REVIEW,
                _tag_with_text(element),
                "Use a Brightspace callout box instead of <blockquote> unless the content is a true quotation. Copy the suggested code and keep the blockquote content inside the callout.",
                _callout_fix(item, text),
                location=page_name,
            )
        )
    return findings



def _check_disallowed_creator_plus(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for element in elements:
        if _is_creator_plus_carousel(element):
            findings.append(
                _finding(
                    item,
                    "Creator+ carousel should be replaced.",
                    "2.1.1 Keyboard; 2.2.2 Pause, Stop, Hide; 4.1.2 Name, Role, Value",
                    Severity.MEDIUM,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "Replace the Creator+ carousel with accessible static content or another approved accessible pattern. Carousels can create keyboard, focus, motion, and screen reader barriers.",
                    location=page_name,
                )
            )
        elif _is_creator_plus_tabs(element):
            findings.append(
                _finding(
                    item,
                    "Creator+ tabs should be replaced.",
                    "2.1.1 Keyboard; 2.4.3 Focus Order; 4.1.2 Name, Role, Value",
                    Severity.MEDIUM,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "Replace the Creator+ tabs with accessible code, such as visible headings and sections or another approved accessible tab pattern. Tabs can create keyboard, focus order, and screen reader barriers.",
                    location=page_name,
                )
            )
    return findings


def _is_creator_plus_carousel(element: Element) -> bool:
    return element.tag == "div" and "d2l-cplus-carousel" in _class_set(element)


def _is_creator_plus_tabs(element: Element) -> bool:
    classes = _class_set(element)
    return (
        element.tag == "div"
        and "d2l-element" in classes
        and element.attrs.get("data-type", "").lower() == "horizontal"
        and element.attrs.get("role", "").lower() == "section"
    )

def _check_span_formatting(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    formatting_terms = ("font", "margin", "padding", "color", "background", "text-align", "line-height")
    for element in elements:
        if element.tag != "span" or _has_language_attribute(element):
            continue
        if _is_inside_approved_callout(element):
            continue
        if _is_inside_replaced_xml_figure(item, element, elements):
            continue
        style = element.attrs.get("style", "").lower()
        if any(term in style for term in formatting_terms):
            findings.append(
                _finding(
                    item,
                    "Span tag appears to be used for visual formatting.",
                    "1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _tag_with_text(element),
                    "Avoid using <span> for font, margin, or layout formatting. Use semantic HTML and template classes instead. Spans with language attributes for foreign-language text are okay.",
                    _visible_text(element.text),
                    location=page_name,
                )
            )
    return findings


def _check_inline_style_rules(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for element in elements:
        style = element.attrs.get("style", "")
        if not style:
            continue
        if _is_inside_approved_callout(element):
            continue
        if _is_inside_replaced_xml_figure(item, element, elements):
            continue
        if _is_quiz_or_survey_xml(item) and element.tag in {"figure", "figcaption", "img"}:
            continue
        if _uses_xml_figure_pattern(item) and element.tag in {"figure", "figcaption", "img"}:
            continue
        style_lower = re.sub(r"\s+", "", style.lower())
        approved_xml_figure_or_image_style = _is_approved_xml_inline_figure_style(item, element, elements)
        if element.tag == "li":
            findings.append(
                _finding(
                    item,
                    "List item has inline style formatting.",
                    "1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _tag_with_text(element),
                    "Remove inline style formatting from <li> tags and use semantic list markup plus approved template styles.",
                    f"<li>{html.escape(_visible_text(element.text) or 'List item text')}</li>",
                    location=page_name,
                )
            )
        if element.tag in {"figure", "figcaption"} and not approved_xml_figure_or_image_style:
            findings.append(
                _finding(
                    item,
                    "Figure or figcaption has inline style formatting.",
                    "1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _tag_with_text(element),
                    "Remove inline style formatting from <figure> and <figcaption>. Use the approved template CSS instead.",
                    location=page_name,
                )
            )
        if element.tag == "img":
            if _is_ignored_template_image(element):
                continue
            if approved_xml_figure_or_image_style:
                continue
            findings.append(
                _finding(
                    item,
                    "Image tag has inline style formatting.",
                    "1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "Remove inline style formatting from <img> tags and use the approved figure/template CSS.",
                    location=page_name,
                )
            )
        if not approved_xml_figure_or_image_style and (style_lower == "text-align:left;" or "text-align:left;" in style_lower):
            findings.append(
                _finding(
                    item,
                    'Inline style uses text-align: left.',
                    "1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _tag_with_text(element),
                    'Remove style="text-align: left;" unless there is a documented reason it is needed.',
                    location=page_name,
                )
            )
        elif element.tag not in {"span", "li", "figure", "figcaption", "img"} and not approved_xml_figure_or_image_style:
            findings.append(
                _finding(
                    item,
                    "HTML tag has inline style formatting.",
                    "1.3.1 Info and Relationships; 1.4.3 Contrast (Minimum)",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    _tag_with_text(element),
                    f"Remove the inline style from the <{element.tag}> tag and use semantic HTML plus approved template classes or CSS instead.",
                    location=page_name,
                )
            )
    return findings


def _is_inside_approved_callout(element: Element) -> bool:
    current: Element | None = element
    while current:
        if _is_brightspace_callout_root(current) or _is_xml_info_callout_root(current):
            return True
        current = current.parent
    return False


def _is_brightspace_callout_root(element: Element) -> bool:
    classes = _class_set(element)
    return (
        element.tag == "div"
        and "d2l-element" in classes
        and element.attrs.get("data-type") == "noicon"
        and element.attrs.get("role") == "section"
    )


def _is_xml_info_callout_root(element: Element) -> bool:
    if element.tag != "div":
        return False
    normalized_style = _normalized_style(element.attrs.get("style", ""))
    required = (
        "background-color:#e7f3fe",
        "border-left:6pxsolid#2196f3",
        "padding:15px",
        "margin:15px0",
        "border-radius:4px",
    )
    return all(part in normalized_style for part in required)


def _class_set(element: Element) -> set[str]:
    return {part.strip().lower() for part in element.attrs.get("class", "").split() if part.strip()}


def _normalized_style(style: str) -> str:
    return re.sub(r"\s+", "", style.lower())


def _check_entities(item: CourseItem, markup: str, page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    if _is_quiz_or_survey_xml(item):
        return findings
    for match in REPEATED_NBSP_RE.finditer(markup):
        if _entity_is_inside_url(markup, match.start(), match.end()):
            continue
        findings.append(
            _finding(
                item,
                "HTML entity appears in page text.",
                "1.3.1 Info and Relationships",
                Severity.LOW,
                Confidence.MANUAL_REVIEW,
                _entity_evidence(markup, match.start(), match.end()),
                "Replace repeated nonbreaking spaces such as &nbsp;&nbsp; with normal spacing, indentation, lists, tables, or layout controls. Repeated nonbreaking spaces are often used to push text over visually, which can create confusing reading order and structure.",
                location=page_name,
            )
        )
    return findings


def _is_quiz_or_survey_xml(item: CourseItem) -> bool:
    if item.content_type != "Brightspace XML content":
        return False
    normalized_title = item.title.replace("\\", "/").lower()
    filename = item.path.name.lower()
    return (
        normalized_title.startswith(("quiz/", "survey/"))
        or filename == "questiondb.xml"
        or filename.startswith(("quiz_d2l_", "survey_d2l_"))
        or "/qti_" in normalized_title
    )


def _check_underscore_blanks(item: CourseItem, text_nodes: list[tuple[str, Element | None]], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    if item.content_type != "Brightspace XML content":
        return findings
    for text, parent in text_nodes:
        if parent and parent.tag in {"script", "style"}:
            continue
        match = re.search(r"_{5,}", text)
        if not match:
            continue
        findings.append(
            _finding(
                item,
                "Quiz or survey blank uses underscores instead of [blank].",
                "1.3.1 Info and Relationships",
                Severity.LOW,
                Confidence.MANUAL_REVIEW,
                _visible_text(text),
                "Replace long underscore blanks with [blank] so screen reader users hear a meaningful blank indicator instead of repeated punctuation.",
                text.replace(match.group(0), "[blank]"),
                location=page_name,
            )
        )
    return findings


def _is_allowed_empty_tag(tag: str, attrs: str) -> bool:
    if tag != "div":
        return False
    class_match = re.search(r"class\s*=\s*(['\"])(.*?)\1", attrs, flags=re.IGNORECASE | re.DOTALL)
    if not class_match:
        return False
    classes = {part.strip().lower() for part in class_match.group(2).split()}
    return "timeline-badge" in classes or any(class_name.startswith("d2l-cplus-") for class_name in classes)


def _check_empty_tags(item: CourseItem, markup: str, page_name: str, *, has_expected_template: bool) -> list[Finding]:
    findings: list[Finding] = []
    for match in EMPTY_TAG_RE.finditer(markup):
        tag = match.group("tag").lower()
        attrs = match.group("attrs") or ""
        if tag in VOID_TAGS or tag in {"iframe", "script", "style"}:
            continue
        if tag == "footer" and not has_expected_template:
            continue
        if _is_allowed_empty_tag(tag, attrs):
            continue
        evidence = match.group(0)
        if tag == "td":
            findings.append(
                _finding(
                    item,
                    "Empty table cell should be checked.",
                    "1.3.1 Info and Relationships",
                    Severity.LOW,
                    Confidence.MANUAL_REVIEW,
                    evidence,
                    "Confirm whether the empty table cell is intentional. If it represents missing data, add meaningful content or table context.",
                    location=page_name,
                )
            )
            continue
        findings.append(
            _finding(
                item,
                "Empty HTML tag has no content.",
                "1.3.1 Info and Relationships",
                Severity.LOW,
                Confidence.AUTOMATED,
                evidence,
                "Remove empty tags or add meaningful content if the element is needed.",
                location=page_name,
            )
        )
    return findings


def _check_tables(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for element in elements:
        if element.tag == "table":
            has_header = any(child.tag == "th" and _is_descendant_of(child, element) for child in elements)
            if not has_header:
                findings.append(
                    _finding(
                        item,
                        "Table may be missing header cells.",
                        "1.3.1 Info and Relationships",
                        Severity.MEDIUM,
                        Confidence.MANUAL_REVIEW,
                        _attrs(element),
                        "Use table header cells for data tables. If this is a layout table, consider replacing it with semantic structure.",
                        location=page_name,
                    )
                )
    return findings


def _check_language(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    for element in elements:
        if element.tag == "html":
            if element.attrs.get("lang"):
                return []
            return [
                _finding(
                    item,
                    "Page language is not identified.",
                    "3.1.1 Language of Page",
                    Severity.MEDIUM,
                    Confidence.AUTOMATED,
                    _attrs(element),
                    "Set the page language, such as <html lang=\"en\">.",
                    '<html lang="en">',
                    location=page_name,
                )
            ]
    return []


def _check_color_and_style(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    for element in elements:
        if _is_inside_approved_callout(element):
            continue
        if _is_inside_replaced_xml_figure(item, element, elements):
            continue
        style = element.attrs.get("style", "").lower()
        if "color:" in style or "background" in style:
            findings.append(
                _finding(
                    item,
                    "Color contrast needs review.",
                    "1.4.3 Contrast (Minimum); 1.4.11 Non-text Contrast",
                    Severity.MEDIUM,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "Verify text and visual indicators meet WCAG 2.2 AA contrast requirements: 4.5:1 for normal text, 3:1 for large text and non-text UI indicators.",
                    location=page_name,
                )
            )
            break
    return findings


def _check_embedded_media(item: CourseItem, elements: list[Element], page_name: str) -> list[Finding]:
    findings: list[Finding] = []
    media_tags = {"video", "audio", "iframe", "embed"}
    for element in elements:
        if element.tag in media_tags:
            findings.append(
                _finding(
                    item,
                    "Embedded media needs captions/transcript review.",
                    "1.2.2 Captions (Prerecorded); 1.2.3 Audio Description or Media Alternative",
                    Severity.HIGH,
                    Confidence.MANUAL_REVIEW,
                    _attrs(element),
                    "Confirm prerecorded video has accurate captions and audio or video content has an equivalent transcript or media alternative.",
                    location=page_name,
                )
            )
    return findings


def _looks_like_url(text: str) -> bool:
    clean = text.strip().lower()
    return clean.startswith(("http://", "https://", "www.")) and len(clean) > 30


def _inside_semantic_list(element: Element | None) -> bool:
    while element:
        if element.tag in {"ul", "ol", "li"}:
            return True
        element = element.parent
    return False


def _looks_like_manual_bulleted_list(text: str) -> bool:
    return len(re.findall(r"(?m)(?:^|\\n)\s*[-*]\s+\S", text)) >= 2


def _looks_like_manual_numbered_list(text: str) -> bool:
    clean = _visible_text(text)
    if _looks_like_apa_reference_text(clean):
        return False
    labels: list[tuple[str, int | str]] = []
    for match in re.finditer(r"(?<!\S)(\d{1,2}|[A-Za-z])[\.\)]\s+\S", clean):
        label = match.group(1)
        if label.isdigit():
            labels.append(("number", int(label)))
        else:
            labels.append(("letter", label.lower()))
    return _has_sequential_manual_labels(labels)


def _has_sequential_manual_labels(labels: list[tuple[str, int | str]]) -> bool:
    if len(labels) < 2:
        return False
    for first, second in zip(labels, labels[1:]):
        if first[0] != second[0]:
            continue
        if first[0] == "number" and isinstance(first[1], int) and isinstance(second[1], int):
            if second[1] == first[1] + 1:
                return True
        if first[0] == "letter" and isinstance(first[1], str) and isinstance(second[1], str):
            if ord(second[1]) == ord(first[1]) + 1:
                return True
    return False


def _looks_like_apa_reference_text(text: str) -> bool:
    clean = _visible_text(text)
    if not re.search(r"\([12][0-9]{3}[a-z]?\)", clean):
        return False
    return bool(re.search(r"\b[A-Z][A-Za-z?-??-??-?'?-]+,\s+[A-Z]\.(?:\s*[A-Z]\.)?", clean))


def _looks_like_apa_citation(text: str) -> bool:
    clean = _visible_text(text)
    return bool(re.search(r"\([12][0-9]{3}[a-z]?\)", clean) and URL_RE.search(clean))


def _entity_is_inside_url(markup: str, start: int, end: int) -> bool:
    for match in URL_RE.finditer(markup):
        if match.start() <= start and end <= match.end():
            return True
    for attr_match in re.finditer(r"""(?:href|src)\s*=\s*["'][^"']*["']""", markup, re.IGNORECASE):
        if attr_match.start() <= start and end <= attr_match.end():
            return True
    return False


def _span_is_inside_plain_text_url(text: str, start: int, end: int) -> bool:
    for match in URL_RE.finditer(text):
        if match.start() <= start and end <= match.end():
            return True
    return False


def _email_from_mailto(href: str) -> str:
    if not href.lower().startswith("mailto:"):
        return ""
    address_part = href.split(":", 1)[1].strip().split("?", 1)[0].strip()
    match = EMAIL_RE.search(address_part)
    return match.group(0) if match else ""


def _entity_evidence(markup: str, start: int, end: int) -> str:
    before_text = re.sub(r"<[^>]+>", " ", markup[max(0, start - 80) : start])
    after_text = re.sub(r"<[^>]+>", " ", markup[end : end + 80])
    before_words = re.findall(r"\b[\w'-]+\b", before_text)
    after_words = re.findall(r"\b[\w'-]+\b", after_text)
    before = before_words[-1] if before_words else ""
    after = after_words[0] if after_words else ""
    return " ".join(part for part in (before, markup[start:end], after) if part)


def _text_match_evidence(text: str, start: int, end: int) -> str:
    before_text = text[max(0, start - 80) : start]
    after_text = text[end : end + 80]
    before_words = re.findall(r"\b[\w'-]+\b", before_text)
    after_words = re.findall(r"\b[\w'-]+\b", after_text)
    before = " ".join(before_words[-3:])
    after = " ".join(after_words[:3])
    return " ".join(part for part in (before, text[start:end], after) if part)


def _is_placeholder_title(title: str) -> bool:
    clean = re.sub(r"[^a-z0-9]+", " ", title.lower()).strip()
    placeholders = {
        "basic page",
        "blank page",
        "untitled document",
        "untitled page",
        "new page",
        "page title",
        "add page title here",
        "template",
    }
    return clean in placeholders or clean.startswith("blank page")


def _normalized_text(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _has_language_attribute(element: Element) -> bool:
    return bool(element.attrs.get("lang") or element.attrs.get("xml:lang"))


def _is_internal_brightspace_link(href: str) -> bool:
    if not href or href.startswith(("#", "mailto:", "tel:")):
        return False
    if href.startswith("/d2l/le/"):
        return True
    parsed = urlparse(href)
    return parsed.netloc.lower() == "myclasses.sunyempire.edu"


def _is_brightspace_quicklink_dialog(href: str) -> bool:
    parsed = urlparse(href)
    return parsed.netloc.lower() == "myclasses.sunyempire.edu" and parsed.path.lower() == BRIGHTSPACE_QUICKLINK_DIALOG_PATH


def _is_internal_course_file_link(href: str) -> bool:
    if not _is_internal_brightspace_link(href):
        return False
    parsed = urlparse(href)
    path = unquote(parsed.path).lower()
    return any(path.endswith(extension) for extension in COURSE_FILE_EXTENSIONS)


def _is_external_link(href: str) -> bool:
    if not href or href.startswith(("#", "mailto:", "tel:")):
        return False
    parsed = urlparse(href)
    if parsed.scheme not in {"http", "https"}:
        return False
    return not _is_internal_brightspace_link(href)




