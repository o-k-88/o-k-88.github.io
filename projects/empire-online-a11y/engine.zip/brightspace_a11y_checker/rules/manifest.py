from __future__ import annotations

import html
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path

from ..models import Confidence, CourseItem, Finding, SearchRecord, Severity
from .html import html_search_record_from_markup, scan_html_markup


@dataclass(frozen=True)
class ManifestHtmlRecord:
    title: str
    markup: str
    content_type: str


def scan_manifest_module_intros(
    manifest_path: Path,
    location_url: str = "",
    skip_hidden: bool = False,
    module_intros_only: bool = False,
    content_root: str = "",
) -> tuple[list[Finding], list[SearchRecord]]:
    intro_records, missing_html_pages = _extract_manifest_html_records(
        manifest_path,
        skip_hidden=skip_hidden,
        module_intros_only=module_intros_only,
    )
    findings: list[Finding] = []
    search_records: list[SearchRecord] = []

    for record in intro_records:
        item = CourseItem(
            title=record.title,
            path=manifest_path,
            content_type=record.content_type,
            location_url=location_url,
            content_root=content_root,
        )
        wrapped_markup = _wrap_intro_markup(record.title, record.markup)
        findings.extend(scan_html_markup(item, wrapped_markup))
        search_records.append(html_search_record_from_markup(item, wrapped_markup))

    findings.extend(_missing_html_page_findings(manifest_path, missing_html_pages, location_url))
    return findings, search_records


def _extract_manifest_html_records(
    manifest_path: Path,
    skip_hidden: bool = False,
    module_intros_only: bool = False,
) -> tuple[list[ManifestHtmlRecord], list[tuple[str, str]]]:
    if not manifest_path.exists():
        return [], []

    try:
        root = ET.parse(manifest_path).getroot()
    except ET.ParseError:
        return [], []

    resource_hrefs = _resource_hrefs(root)
    records: list[ManifestHtmlRecord] = []
    missing_html_pages: list[tuple[str, str]] = []
    for element in root.iter():
        if _local_name(element.tag) != "item":
            continue
        if skip_hidden and _is_hidden_item(element):
            continue
        title = _direct_child_text(element, "title")
        if not title:
            continue
        identifierref = element.attrib.get("identifierref", "")
        href = resource_hrefs.get(identifierref, "")
        if module_intros_only and not _is_native_module_intro_record(href, identifierref):
            continue
        fragments = _item_description_fragments(element)
        if fragments:
            records.append(
                ManifestHtmlRecord(
                    title=_record_title(title, href, identifierref),
                    markup="\n".join(fragments),
                    content_type=_record_content_type(href, identifierref),
                )
            )
        if not module_intros_only and _is_local_html_href(href) and not _manifest_referenced_file_exists(manifest_path.parent, href):
            missing_html_pages.append((title, href))
    return records, _dedupe_missing_pages(missing_html_pages)


def _resource_hrefs(root: ET.Element) -> dict[str, str]:
    hrefs: dict[str, str] = {}
    for element in root.iter():
        if _local_name(element.tag) != "resource":
            continue
        identifier = element.attrib.get("identifier", "")
        href = element.attrib.get("href", "")
        if identifier:
            hrefs[identifier] = href
    return hrefs


def _record_title(title: str, href: str, identifierref: str) -> str:
    if identifierref and _is_local_html_href(href):
        return title
    return f"Module intro: {title}"


def _record_content_type(href: str, identifierref: str) -> str:
    if identifierref and _is_local_html_href(href):
        return "Brightspace HTML page metadata"
    return "Brightspace module intro metadata"


def _is_native_module_intro_record(href: str, identifierref: str) -> bool:
    return bool(identifierref) and not href


def _is_local_html_href(href: str) -> bool:
    if not href:
        return False
    if re.match(r"^[a-z][a-z0-9+.-]*:", href, flags=re.IGNORECASE) or href.startswith("/"):
        return False
    return Path(href.replace("\\", "/")).suffix.lower() in {".html", ".htm", ".xhtml"}


def _manifest_referenced_file_exists(root: Path, href: str) -> bool:
    normalized = href.replace("\\", "/").lstrip("./")
    return (root / normalized).exists()


def _dedupe_missing_pages(pages: list[tuple[str, str]]) -> list[tuple[str, str]]:
    seen: set[tuple[str, str]] = set()
    deduped: list[tuple[str, str]] = []
    for title, href in pages:
        key = (title.lower(), href.replace("\\", "/").lower())
        if key in seen:
            continue
        seen.add(key)
        deduped.append((title, href))
    return deduped


def _missing_html_page_findings(manifest_path: Path, pages: list[tuple[str, str]], location_url: str) -> list[Finding]:
    findings: list[Finding] = []
    for title, href in pages:
        findings.append(
            Finding(
                location=title,
                content_type="HTML content page",
                issue="HTML page referenced by manifest was not included in the export.",
                wcag="Scan coverage",
                severity=Severity.LOW,
                confidence=Confidence.MANUAL_REVIEW,
                evidence=href,
                recommendation=(
                    "The Brightspace export references this HTML page, but the file is not present in the ZIP. "
                    "Re-export with course files included or review the page directly in Brightspace; the tool cannot verify "
                    "Bootstrap/template assets until the HTML file is available."
                ),
                source="Cartridge Scan",
                location_url=location_url,
            )
        )
    return findings


def _item_description_fragments(item: ET.Element) -> list[str]:
    fragments: list[str] = []
    description = item.attrib.get("description", "")
    if description:
        fragment = _clean_metadata_fragment(description)
        if fragment:
            fragments.append(fragment)
    fragments.extend(_metadata_description_fragments(item))
    return _dedupe_fragments(fragments)


def _metadata_description_fragments(item: ET.Element) -> list[str]:
    fragments: list[str] = []
    for child in list(item):
        if _local_name(child.tag) != "metadata":
            continue
        _collect_description_strings(child, in_description=False, fragments=fragments)
    return fragments


def _dedupe_fragments(fragments: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for fragment in fragments:
        key = re.sub(r"\s+", " ", fragment).strip().lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(fragment)
    return deduped


def _collect_description_strings(element: ET.Element, in_description: bool, fragments: list[str]) -> None:
    local = _local_name(element.tag)
    next_in_description = in_description or local in {"description", "intro", "introduction"}
    if next_in_description and local == "string" and element.text:
        fragment = _clean_metadata_fragment(element.text)
        if fragment:
            fragments.append(fragment)
    for child in list(element):
        _collect_description_strings(child, next_in_description, fragments)


def _clean_metadata_fragment(value: str) -> str:
    clean = html.unescape(value).strip()
    if not clean:
        return ""
    if _looks_like_markup(clean):
        return clean
    if len(re.sub(r"\s+", " ", clean)) >= 40:
        return f"<p>{html.escape(clean)}</p>"
    return ""


def _wrap_intro_markup(title: str, markup: str) -> str:
    escaped_title = html.escape(title)
    return (
        f'<!doctype html><html lang="en"><head><title>{escaped_title}</title></head>'
        f'<body><h1 class="page-title">{escaped_title}</h1>{markup}</body></html>'
    )


def _direct_child_text(element: ET.Element, name: str) -> str:
    for child in list(element):
        if _local_name(child.tag) == name and child.text and child.text.strip():
            return child.text.strip()
    return ""


def _looks_like_markup(value: str) -> bool:
    return bool(re.search(r"</?(p|div|span|img|a|ul|ol|li|h[1-6]|figure|figcaption|strong|em|b|i)\b", value, re.IGNORECASE))


def _is_hidden_item(element: ET.Element) -> bool:
    for key, value in element.attrib.items():
        local_key = key.split("}", 1)[-1].lower()
        if local_key in {"isvisible", "visible"} and value.strip().lower() in {"false", "0", "no"}:
            return True
    return False


def _local_name(tag: str) -> str:
    return tag.split("}", 1)[-1]
