from .html import scan_html
from .xml import scan_xml

__all__ = ["scan_html", "scan_xml"]
