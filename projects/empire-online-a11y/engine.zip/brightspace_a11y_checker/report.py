from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
import hashlib
from html import escape
import json
from pathlib import Path
import re

from .checklist import CHECKLIST_ITEMS
from .models import Finding, SearchRecord


BOOTSTRAP_TEMPLATE_ISSUE = "Page does not use the expected SUNY Empire Bootstrap template."
XML_FIGURE_PATTERN_ISSUE = "XML image is not using the expected styled figure pattern."


def write_html_report(findings: list[Finding], output_path: Path, source_name: str, search_records: list[SearchRecord] | None = None) -> None:
    counts = Counter(finding.severity.value for finding in findings)
    generated = datetime.now().strftime("%Y-%m-%d %H:%M")
    grouped_findings = _group_findings(findings)
    search_json = _search_records_json(search_records or [])
    first_sentences = _first_sentence_lookup(search_records or [])
    rows = "\n".join(
        _render_page_record(index, location, page_findings, first_sentences.get(location, ""))
        for index, (location, _location_url, page_findings) in enumerate(grouped_findings, start=1)
    )

    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Empire Online A11y Checklist</title>
  <style>
    :root {{
      --page-bg: #eef4f8;
      --surface: #ffffff;
      --surface-soft: #f8fbfd;
      --text: #172033;
      --muted: #475569;
      --border: #bfcedb;
      --border-soft: #d7e1ea;
      --brand: #174ea6;
      --brand-dark: #102a43;
      --focus: #f59e0b;
      --success: #0f7a3d;
      --success-soft: #e7f7ee;
      --critical: #9b1c1c;
      --critical-soft: #fff1f1;
      --high: #a34100;
      --high-soft: #fff3e6;
      --medium: #7a5b00;
      --medium-soft: #fff8db;
      --low: #174ea6;
      --low-soft: #edf5ff;
      --shadow: 0 12px 32px rgba(15, 23, 42, 0.10);
    }}
    * {{ box-sizing: border-box; }}
    html {{ overflow-x: hidden; }}
    body {{ font-family: "Segoe UI", Arial, sans-serif; line-height: 1.55; margin: 0; color: var(--text); background: var(--page-bg); font-size: 16px; overflow-wrap: anywhere; }}
    .skip-link {{ position: absolute; left: 18px; top: -60px; z-index: 10; background: var(--focus); color: #111827; padding: 10px 14px; border-radius: 6px; font-weight: 700; }}
    .skip-link:focus {{ top: 12px; outline: 3px solid #111827; }}
    header {{ background: linear-gradient(135deg, #102a43 0%, #174ea6 100%); color: white; padding: clamp(20px, 3vw, 30px) clamp(18px, 4vw, 36px); border-bottom: 6px solid #7aa7d9; }}
    .header-row {{ display: flex; justify-content: space-between; gap: 18px; align-items: flex-start; max-width: 1320px; margin: 0 auto; }}
    .eyebrow {{ margin: 0 0 6px; text-transform: uppercase; letter-spacing: 0; font-size: 13px; font-weight: 700; color: #dbeafe; }}
    .theme-toggle {{ display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.14); border: 1px solid rgba(255,255,255,0.65); border-radius: 999px; padding: 8px 12px; white-space: nowrap; font-weight: 700; }}
    .theme-toggle input {{ accent-color: #f59e0b; width: 18px; height: 18px; }}
    main {{ width: min(100%, 1320px); padding: clamp(18px, 3vw, 28px) clamp(18px, 4vw, 36px) 42px; margin: 0 auto; }}
    h1 {{ margin: 0 0 8px; font-size: clamp(24px, 4vw, 32px); line-height: 1.18; }}
    h2 {{ margin-top: 32px; color: var(--brand-dark); }}
    p {{ max-width: 88ch; }}
    table {{ width: 100%; border-collapse: separate; border-spacing: 0 16px; }}
    th {{ text-align: left; padding: 8px 12px; color: var(--brand-dark); font-size: 15px; }}
    td {{ vertical-align: top; padding: 20px; border-top: 1px solid var(--border-soft); border-bottom: 1px solid var(--border-soft); }}
    tr.finding td {{ border-top: 4px solid #dc2626; }}
    td:first-child {{ border-left: 7px solid #6b7280; border-radius: 8px 0 0 8px; width: 31%; }}
    td:last-child {{ border-right: 1px solid var(--border-soft); border-radius: 0 8px 8px 0; }}
    .summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(min(150px, 100%), 1fr)); gap: 12px; margin-top: 18px; }}
    .summary button {{ background: var(--surface); border: 1px solid var(--border); padding: 16px; border-radius: 8px; text-align: left; cursor: pointer; font: inherit; color: inherit; box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04); }}
    .summary button strong {{ font-size: 22px; display: inline-block; margin-bottom: 2px; }}
    .summary button:hover, .summary button[aria-pressed="true"] {{ border-color: var(--brand); background: #f5f9ff; }}
    .summary button[aria-pressed="true"] {{ box-shadow: 0 0 0 3px rgba(23, 78, 166, 0.18); }}
    button:focus, input:focus, summary:focus, .theme-toggle:focus-within {{ outline: 3px solid var(--focus); outline-offset: 3px; }}
    .intro-card {{ background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 16px 18px; margin-top: 18px; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.05); }}
    .progress-wrap {{ background: var(--surface); border: 1px solid var(--border); padding: 18px; border-radius: 10px; margin-top: 18px; box-shadow: var(--shadow); }}
    .progress-head {{ display: flex; align-items: baseline; justify-content: space-between; gap: 16px; flex-wrap: wrap; margin-bottom: 10px; }}
    .progress-head h2 {{ margin: 0; }}
    .progress-track {{ background: #d7e1ea; border-radius: 999px; min-height: 22px; overflow: hidden; border: 1px solid #9fb2c7; }}
    .progress-bar {{ background: linear-gradient(90deg, #174ea6, #0f7a3d); height: 22px; width: 0%; transition: width 0.2s ease; }}
    .complete-message {{ display: none; margin-top: 12px; font-weight: 700; color: #0f6b36; background: var(--success-soft); border: 1px solid #9dd9b4; border-radius: 8px; padding: 10px 12px; }}
    .undo-wrap {{ margin-top: 14px; }}
    .undo-button:disabled {{ opacity: 0.55; cursor: not-allowed; }}
    .finding.Critical td {{ background: var(--critical-soft); }}
    .finding.High td {{ background: var(--high-soft); }}
    .finding.Medium td {{ background: var(--medium-soft); }}
    .finding.Low td {{ background: var(--low-soft); }}
    .finding.Critical td:first-child {{ border-left-color: var(--critical); }}
    .finding.High td:first-child {{ border-left-color: var(--high); }}
    .finding.Medium td:first-child {{ border-left-color: var(--medium); }}
    .finding.Low td:first-child {{ border-left-color: var(--low); }}
    .finding:nth-child(even).Critical td {{ background: #ffe7e7; }}
    .finding:nth-child(even).High td {{ background: #ffe8cc; }}
    .finding:nth-child(even).Medium td {{ background: #fff1b8; }}
    .finding:nth-child(even).Low td {{ background: #dcecff; }}
    .finding.page-completed td {{ background: var(--success-soft); border-color: #9dd9b4; }}
    .finding.page-completed td:first-child {{ border-left-color: var(--success); }}
    .finding.page-completed .page-title::after {{ content: " Page complete"; display: block; margin-top: 8px; color: #0f6b36; font-size: 14px; font-weight: 700; }}
    .page-title {{ font-size: 18px; line-height: 1.35; overflow-wrap: anywhere; }}
    .issue-item {{ margin: 0 0 16px; padding: 16px; border: 1px solid var(--border-soft); border-radius: 8px; background: rgba(255,255,255,0.82); box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04); }}
    .issue-header {{ display: flex; gap: 10px; align-items: flex-start; }}
    .page-actions {{ margin: 14px 0 0; display: flex; gap: 8px; align-items: center; }}
    .done-button, .page-done-button, .similar-done-button, .undo-button, .copy-button {{ border: 1px solid #8094aa; background: #ffffff; border-radius: 7px; cursor: pointer; color: var(--text); }}
    .done-button {{ border-radius: 999px; width: 30px; height: 30px; flex: 0 0 30px; font-weight: 800; }}
    .page-done-button, .undo-button {{ padding: 8px 12px; font: inherit; }}
    .similar-done-button {{ margin-left: auto; padding: 5px 9px; font: inherit; font-size: 13px; }}
    .copy-button {{ position: relative; width: 26px; height: 26px; padding: 0; vertical-align: middle; }}
    .copy-button::before, .copy-button::after {{ content: ""; position: absolute; width: 11px; height: 11px; border: 1.5px solid #334155; background: white; }}
    .copy-button::before {{ left: 6px; top: 8px; }}
    .copy-button::after {{ left: 11px; top: 4px; }}
    .copy-button.copied {{ border-color: var(--success); background: var(--success-soft); }}
    .done-button[aria-pressed="true"], .page-done-button[aria-pressed="true"] {{ background: var(--success); color: white; border-color: var(--success); }}
    .issue-item.completed {{ display: none; }}
    .page-first-sentence {{ margin: 14px 0 0; color: #334155; font-size: 14px; }}
    .course-search {{ background: var(--surface); border: 1px solid var(--border); border-radius: 10px; margin-top: 18px; padding: 18px; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.05); }}
    .course-search h2 {{ margin-top: 0; }}
    .search-row {{ display: flex; gap: 8px; align-items: center; }}
    .search-row input {{ flex: 1; padding: 10px 12px; border: 1px solid #8094aa; border-radius: 7px; font: inherit; color: var(--text); }}
    .search-results {{ margin-top: 12px; display: grid; gap: 10px; }}
    .search-result {{ border: 1px solid var(--border-soft); border-radius: 8px; padding: 12px; background: var(--surface-soft); }}
    .search-result-title {{ font-weight: 700; }}
    .search-snippet mark {{ background: #fde68a; padding: 0 2px; color: #111827; }}
    .recent-completed, .completed-archive {{ margin-top: 18px; }}
    .recent-completed {{ display: none; }}
    .recent-completed summary {{ cursor: pointer; font-weight: 700; font-size: 20px; margin-top: 24px; color: var(--brand-dark); }}
    .completed-archive h2 {{ margin-top: 40px; }}
    .checklist-info {{ margin-top: 28px; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 16px 20px; }}
    .checklist-info summary {{ cursor: pointer; font-weight: 700; color: var(--brand-dark); }}
    .meta {{ display: flex; flex-wrap: wrap; gap: 8px; margin: 8px 0 14px; }}
    .pill {{ background: #edf2f7; border: 1px solid #d8e2ec; border-radius: 999px; padding: 4px 10px; font-size: 13px; color: #172033; }}
    pre {{ white-space: pre-wrap; background: #f3f6f9; padding: 12px; border-radius: 6px; overflow-wrap: anywhere; border: 1px solid #e2e8f0; }}
    code {{ overflow-wrap: anywhere; }}
    body.dark-mode {{ color: #e5edf6; background: #0f172a; }}
    body.dark-mode header {{ background: linear-gradient(135deg, #020617 0%, #0f2d55 100%); border-bottom-color: #2b6cb0; }}
    body.dark-mode h2, body.dark-mode .recent-completed summary, body.dark-mode .checklist-info summary {{ color: #dbeafe; }}
    body.dark-mode .summary button,
    body.dark-mode .intro-card,
    body.dark-mode .progress-wrap,
    body.dark-mode .course-search,
    body.dark-mode .checklist-info,
    body.dark-mode .done-button,
    body.dark-mode .page-done-button,
    body.dark-mode .similar-done-button,
    body.dark-mode .undo-button,
    body.dark-mode .copy-button {{ background: #111827; color: #e5edf6; border-color: #64748b; }}
    body.dark-mode .summary button:hover,
    body.dark-mode .summary button[aria-pressed="true"] {{ background: #1e293b; border-color: #93c5fd; }}
    body.dark-mode th {{ color: #dbeafe; }}
    body.dark-mode td {{ border-color: #475569; }}
    body.dark-mode .progress-track {{ background: #1e293b; border-color: #64748b; }}
    body.dark-mode .complete-message {{ background: #0f3324; color: #bbf7d0; border-color: #22c55e; }}
    body.dark-mode .finding.Critical td {{ background: #3f1d1d; }}
    body.dark-mode .finding.High td {{ background: #43250f; }}
    body.dark-mode .finding.Medium td {{ background: #3b310d; }}
    body.dark-mode .finding.Low td {{ background: #112947; }}
    body.dark-mode .finding:nth-child(even).Critical td {{ background: #4a2020; }}
    body.dark-mode .finding:nth-child(even).High td {{ background: #512b12; }}
    body.dark-mode .finding:nth-child(even).Medium td {{ background: #44380f; }}
    body.dark-mode .finding:nth-child(even).Low td {{ background: #143154; }}
    body.dark-mode .finding.page-completed td {{ background: #0f3324; border-color: #166534; }}
    body.dark-mode .issue-item,
    body.dark-mode .search-result {{ background: rgba(15, 23, 42, 0.84); border-color: #475569; }}
    body.dark-mode .pill {{ background: #1f2937; border-color: #475569; color: #e5edf6; }}
    body.dark-mode .page-first-sentence {{ color: #cbd5e1; }}
    body.dark-mode pre {{ background: #020617; color: #e5edf6; border-color: #334155; }}
    body.dark-mode .search-row input {{ background: #020617; color: #e5edf6; border-color: #64748b; }}
    body.dark-mode .copy-button::before,
    body.dark-mode .copy-button::after {{ background: #111827; border-color: #e5edf6; }}
    @media (max-width: 1100px) {{
      td:first-child {{ width: 38%; }}
      .issue-header {{ flex-wrap: wrap; }}
      .similar-done-button {{ margin-left: 0; }}
    }}
    @media (max-width: 820px) {{
      .header-row, .search-row {{ display: block; }}
      .theme-toggle {{ margin-top: 16px; }}
      table, thead, tbody, tr, th, td {{ display: block; width: 100%; }}
      table {{ border-spacing: 0 16px; }}
      thead {{ position: absolute; left: -9999px; }}
      td:first-child, td:last-child {{ border-radius: 8px; border-right: 1px solid var(--border-soft); }}
      td:last-child {{ border-top: 0; }}
      .search-row input, .search-row button {{ width: 100%; margin-top: 8px; }}
    }}
    @media (max-width: 560px) {{
      body {{ font-size: 15px; }}
      .summary {{ grid-template-columns: 1fr; }}
      .progress-head {{ display: block; }}
      .issue-item, .course-search, .intro-card, .progress-wrap {{ padding: 14px; }}
      .meta {{ gap: 6px; }}
      .pill {{ font-size: 12px; }}
      .page-actions, .issue-header {{ display: block; }}
      .done-button, .copy-button {{ margin-bottom: 8px; }}
      .similar-done-button, .page-done-button, .undo-button {{ width: 100%; margin-top: 8px; }}
    }}
    @media (prefers-reduced-motion: reduce) {{
      .progress-bar {{ transition: none; }}
    }}
  </style>
</head>
<body>
  <a class="skip-link" href="#checklistHeading">Skip to checklist</a>
  <header>
    <div class="header-row">
      <div>
        <p class="eyebrow">Brightspace course accessibility report</p>
        <h1>Empire Online A11y Checklist</h1>
        <div>Source: {escape(source_name)} | Generated: {escape(generated)}</div>
      </div>
      <label class="theme-toggle"><input id="darkModeToggle" type="checkbox"> Dark mode</label>
    </div>
  </header>
  <main>
    <section class="progress-wrap" aria-label="Remediation progress">
      <div class="progress-head">
        <h2>Progress</h2>
        <strong id="progressText" aria-live="polite">0% complete</strong>
      </div>
      <div id="progressTrack" class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-labelledby="progressText"><div id="progressBar" class="progress-bar"></div></div>
      <div id="completeMessage" class="complete-message" aria-live="polite">Success. All checklist items are checked.</div>
      <div id="undoWrap" class="undo-wrap"><button type="button" id="undoButton" class="undo-button" disabled>Undo last completion</button></div>
    </section>
    <section class="intro-card" aria-label="How to use this report">
      <strong>How to use this report:</strong> Work through the checklist, use the copy buttons for page names and evidence, then mark each issue or page fixed. Your progress is saved in this browser for this report run.
    </section>
    <section class="summary" aria-label="Finding summary">
      <button type="button" data-filter="all" aria-pressed="true"><strong>{len(findings)}</strong><br>Total findings</button>
      <button type="button" data-filter="all" aria-pressed="true"><strong>{len(grouped_findings)}</strong><br>Pages/items</button>
      <button type="button" data-filter="Critical" aria-pressed="false"><strong>{counts.get("Critical", 0)}</strong><br>Critical</button>
      <button type="button" data-filter="High" aria-pressed="false"><strong>{counts.get("High", 0)}</strong><br>High</button>
      <button type="button" data-filter="Medium" aria-pressed="false"><strong>{counts.get("Medium", 0)}</strong><br>Medium</button>
      <button type="button" data-filter="Low" aria-pressed="false"><strong>{counts.get("Low", 0)}</strong><br>Low</button>
    </section>
    <section class="course-search" aria-label="Course content search">
      <h2>Course Search</h2>
      <div class="search-row">
        <input id="courseSearchInput" type="search" placeholder="Search with words, phrases, OR, NOT" autocomplete="off">
        <button type="button" id="clearSearchButton" class="undo-button">Clear</button>
      </div>
      <div id="courseSearchStatus" class="meta">Search {len(search_records or [])} indexed course item(s).</div>
      <div id="courseSearchResults" class="search-results"></div>
    </section>
    <details id="recentCompleted" class="recent-completed" aria-label="Most recently completed page">
      <summary>Most Recently Completed Page</summary>
      <table><tbody id="recentCompletedBody"></tbody></table>
    </details>
    <h2 id="checklistHeading">Checklist</h2>
    <table aria-label="Accessibility remediation checklist">
      <thead><tr><th>Page</th><th>Issue(s)</th></tr></thead>
      <tbody id="checklist">
        {rows or '<tr><td colspan="2">No findings were detected by the current automated rules.</td></tr>'}
      </tbody>
    </table>
    <section id="completedArchive" class="completed-archive" aria-label="Older completed pages"><h2>Older Completed Pages</h2><table><tbody></tbody></table></section>
    <details class="checklist-info">
      <summary>Show the checks this tool runs</summary>
      <ul>
        {_render_checklist_items()}
      </ul>
    </details>
  </main>
  <script>
    const reportRunKey = {f"{source_name}|{generated}"!r};
    const storageKey = "brightspace-a11y-checklist:" + reportRunKey;
    const themeKey = "brightspace-a11y-checklist-theme:" + {source_name!r};
    const saved = new Set(JSON.parse(localStorage.getItem(storageKey) || "[]"));
    const darkModeToggle = document.getElementById("darkModeToggle");
    const checklist = document.getElementById("checklist");
    const recentCompleted = document.getElementById("recentCompleted");
    const recentCompletedBody = document.getElementById("recentCompletedBody");
    const completedArchiveBody = document.querySelector("#completedArchive tbody");
    const items = Array.from(document.querySelectorAll(".issue-item"));
    const pages = Array.from(document.querySelectorAll(".finding"));
    const progressText = document.getElementById("progressText");
    const progressBar = document.getElementById("progressBar");
    const progressTrack = document.getElementById("progressTrack");
    const completeMessage = document.getElementById("completeMessage");
    const undoWrap = document.getElementById("undoWrap");
    const undoButton = document.getElementById("undoButton");
    const searchIndex = {search_json};
    const searchInput = document.getElementById("courseSearchInput");
    const searchResults = document.getElementById("courseSearchResults");
    const searchStatus = document.getElementById("courseSearchStatus");
    const clearSearchButton = document.getElementById("clearSearchButton");
    const undoStack = [];

    function applyTheme() {{
      const darkMode = localStorage.getItem(themeKey) === "dark";
      document.body.classList.toggle("dark-mode", darkMode);
      darkModeToggle.checked = darkMode;
    }}

    darkModeToggle.addEventListener("change", () => {{
      localStorage.setItem(themeKey, darkModeToggle.checked ? "dark" : "light");
      applyTheme();
    }});

    function persist() {{
      const done = items.filter(item => item.classList.contains("completed")).map(item => item.dataset.id);
      localStorage.setItem(storageKey, JSON.stringify(done));
    }}

    function syncPageState(page) {{
      const pageItems = Array.from(page.querySelectorAll(".issue-item"));
      const allDone = pageItems.length > 0 && pageItems.every(item => item.classList.contains("completed"));
      page.classList.toggle("page-completed", allDone);
      const pageButton = page.querySelector(".page-done-button");
      if (pageButton) {{
        pageButton.setAttribute("aria-pressed", allDone ? "true" : "false");
        pageButton.textContent = allDone ? "Page marked fixed" : "Mark entire page fixed";
      }}
      return allDone;
    }}

    function moveCompletedPage(page) {{
      if (!page.classList.contains("page-completed")) {{
        return;
      }}
      const current = recentCompletedBody.querySelector(".finding");
      if (current && current !== page) {{
        completedArchiveBody.prepend(current);
      }}
      recentCompletedBody.appendChild(page);
      recentCompleted.style.display = "block";
    }}

    function setUndoState() {{
      undoButton.disabled = undoStack.length === 0;
    }}

    function restoreChecklistOrder() {{
      Array.from(checklist.children)
        .filter(page => page.classList.contains("finding"))
        .sort((left, right) => Number(left.dataset.order) - Number(right.dataset.order))
        .forEach(page => checklist.appendChild(page));
    }}

    function updateProgress() {{
      const total = items.length;
      const done = items.filter(item => item.classList.contains("completed")).length;
      const percent = total ? Math.round((done / total) * 100) : 100;
      progressText.textContent = `${{done}} of ${{total}} fixed (${{percent}}% complete)`;
      progressBar.style.width = percent + "%";
      progressTrack.setAttribute("aria-valuenow", String(percent));
      completeMessage.style.display = total && done === total ? "block" : "none";
      pages.forEach(page => syncPageState(page));
    }}

    items.forEach(item => {{
      if (saved.has(item.dataset.id)) {{
        item.classList.add("completed");
        const button = item.querySelector(".done-button");
        button.textContent = "\\u2713";
        button.setAttribute("aria-pressed", "true");
      }}
      item.querySelector(".done-button").addEventListener("click", () => {{
        item.classList.toggle("completed");
        const button = item.querySelector(".done-button");
        const fixed = item.classList.contains("completed");
        button.textContent = fixed ? "\\u2713" : "";
        button.setAttribute("aria-pressed", fixed ? "true" : "false");
        const page = item.closest(".finding");
        if (fixed) {{
          undoStack.push({{ changedItems: [item], page }});
          setUndoState();
        }}
        persist();
        updateProgress();
        if (syncPageState(page)) {{
          moveCompletedPage(page);
        }} else if (page.parentElement !== checklist) {{
          checklist.appendChild(page);
        }}
      }});
    }});

    document.querySelectorAll(".similar-done-button").forEach(button => {{
      button.addEventListener("click", () => {{
        const currentItem = button.closest(".issue-item");
        const page = button.closest(".finding");
        const issue = currentItem.dataset.issue;
        const newlyMarked = [];
        Array.from(page.querySelectorAll(".issue-item")).forEach(pageItem => {{
          if (pageItem.dataset.issue === issue && !pageItem.classList.contains("completed")) {{
            pageItem.classList.add("completed");
            const issueButton = pageItem.querySelector(".done-button");
            issueButton.textContent = "\\u2713";
            issueButton.setAttribute("aria-pressed", "true");
            newlyMarked.push(pageItem);
          }}
        }});
        if (newlyMarked.length) {{
          undoStack.push({{ changedItems: newlyMarked, page }});
          setUndoState();
        }}
        persist();
        updateProgress();
        if (syncPageState(page)) {{
          moveCompletedPage(page);
        }} else if (page.parentElement !== checklist) {{
          checklist.appendChild(page);
        }}
      }});
    }});

    document.querySelectorAll(".page-done-button").forEach(button => {{
      button.addEventListener("click", () => {{
        const page = button.closest(".finding");
        const pageItems = Array.from(page.querySelectorAll(".issue-item")).filter(item => item.style.display !== "none");
        const newlyMarked = [];
        pageItems.forEach(item => {{
          if (!item.classList.contains("completed")) {{
            item.classList.add("completed");
            const issueButton = item.querySelector(".done-button");
            issueButton.textContent = "\\u2713";
            issueButton.setAttribute("aria-pressed", "true");
            newlyMarked.push(item);
          }}
        }});
        if (newlyMarked.length) {{
          undoStack.push({{ changedItems: newlyMarked, page }});
          setUndoState();
        }}
        persist();
        updateProgress();
        moveCompletedPage(page);
      }});
    }});

    undoButton.addEventListener("click", () => {{
      const lastCompletion = undoStack.pop();
      setUndoState();
      if (!lastCompletion) {{
        return;
      }}
      lastCompletion.changedItems.forEach(item => {{
        item.classList.remove("completed");
        const button = item.querySelector(".done-button");
        button.textContent = "";
        button.setAttribute("aria-pressed", "false");
      }});
      checklist.appendChild(lastCompletion.page);
      restoreChecklistOrder();
      if (!recentCompletedBody.querySelector(".finding")) {{
        recentCompleted.style.display = "none";
      }}
      persist();
      updateProgress();
    }});

    function applySeverityFilter(filter) {{
      items.forEach(item => {{
        item.style.display = filter === "all" || item.dataset.severity === filter ? "" : "none";
      }});
      pages.forEach(page => {{
        const pageItems = Array.from(page.querySelectorAll(".issue-item"));
        const hasVisibleItems = filter === "all" || pageItems.some(item => item.dataset.severity === filter);
        page.style.display = hasVisibleItems ? "" : "none";
      }});
      document.querySelectorAll(".summary button").forEach(summaryButton => {{
        summaryButton.setAttribute("aria-pressed", summaryButton.dataset.filter === filter ? "true" : "false");
      }});
      updateProgress();
    }}

    document.querySelectorAll(".summary button").forEach(button => {{
      button.addEventListener("click", () => {{
        applySeverityFilter(button.dataset.filter);
      }});
    }});

    document.querySelectorAll(".copy-button").forEach(button => {{
      button.addEventListener("click", async () => {{
        try {{
          await navigator.clipboard.writeText(button.dataset.copy || "");
          button.classList.add("copied");
          setTimeout(() => button.classList.remove("copied"), 900);
        }} catch (error) {{
          const textArea = document.createElement("textarea");
          textArea.value = button.dataset.copy || "";
          document.body.appendChild(textArea);
          textArea.select();
          document.execCommand("copy");
          textArea.remove();
        }}
      }});
    }});

    function escapeHtml(value) {{
      return String(value).replace(/[&<>"']/g, character => ({{
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "\\"": "&quot;",
        "'": "&#39;"
      }}[character]));
    }}

    function parseBooleanSearch(query) {{
      const tokens = query.match(/"[^"]+"|\\S+/g) || [];
      const groups = [[]];
      const excludes = [];
      let negateNext = false;
      tokens.forEach(rawToken => {{
        let token = rawToken.replace(/^"|"$/g, "").replace(/^[()]+|[()]+$/g, "").trim().toLowerCase();
        if (!token) {{
          return;
        }}
        if (token === "and") {{
          return;
        }}
        if (token === "or") {{
          if (groups[groups.length - 1].length) {{
            groups.push([]);
          }}
          return;
        }}
        if (token === "not") {{
          negateNext = true;
          return;
        }}
        const negative = negateNext || token.startsWith("-");
        if (token.startsWith("-")) {{
          token = token.slice(1);
        }}
        negateNext = false;
        if (token.length < 2) {{
          return;
        }}
        if (negative) {{
          excludes.push(token);
        }} else {{
          groups[groups.length - 1].push(token);
        }}
      }});
      return {{ groups: groups.filter(group => group.length), excludes }};
    }}

    function recordMatchesSearch(record, parsed) {{
      const text = record.searchText || "";
      if (!parsed.groups.length) {{
        return false;
      }}
      if (parsed.excludes.some(term => text.includes(term))) {{
        return false;
      }}
      return parsed.groups.some(group => group.every(term => text.includes(term)));
    }}

    function firstSearchTerm(record, parsed, fallback) {{
      const text = record.searchText || "";
      for (const group of parsed.groups) {{
        for (const term of group) {{
          if (text.includes(term)) {{
            return term;
          }}
        }}
      }}
      return fallback;
    }}

    function snippetFor(record, query, parsed) {{
      const text = record.text || "";
      const term = firstSearchTerm(record, parsed, query).toLowerCase();
      const lower = text.toLowerCase();
      const index = lower.indexOf(term);
      if (index < 0) {{
        return escapeHtml(text.slice(0, 220));
      }}
      const start = Math.max(0, index - 80);
      const end = Math.min(text.length, index + term.length + 120);
      const before = escapeHtml(text.slice(start, index));
      const match = escapeHtml(text.slice(index, index + term.length));
      const after = escapeHtml(text.slice(index + term.length, end));
      return `${{start > 0 ? "..." : ""}}${{before}}<mark>${{match}}</mark>${{after}}${{end < text.length ? "..." : ""}}`;
    }}

    function renderSearch() {{
      const query = searchInput.value.trim();
      searchResults.innerHTML = "";
      if (query.length < 2) {{
        searchStatus.textContent = `Search ${{searchIndex.length}} indexed course item(s). Type at least 2 characters. Boolean search supports AND, OR, NOT, and quoted phrases.`;
        return;
      }}
      const parsed = parseBooleanSearch(query);
      const matches = searchIndex
        .filter(record => recordMatchesSearch(record, parsed))
        .slice(0, 50);
      searchStatus.textContent = `${{matches.length}} result(s) shown for "${{query}}".`;
      if (!matches.length) {{
        searchResults.innerHTML = '<div class="search-result">No matching course text found.</div>';
        return;
      }}
      searchResults.innerHTML = matches.map(record => `
        <div class="search-result">
          <div class="search-result-title">${{escapeHtml(record.title)}} <button type="button" class="copy-button dynamic-copy" data-copy="${{escapeHtml(record.title)}}" aria-label="Copy search result title" title="Copy search result title"></button></div>
          <div class="meta"><span class="pill">${{escapeHtml(record.contentType)}}</span><span class="pill">${{escapeHtml(record.source)}}</span></div>
          <div class="search-snippet">${{snippetFor(record, query, parsed)}}</div>
        </div>
      `).join("");
      searchResults.querySelectorAll(".dynamic-copy").forEach(button => {{
        button.addEventListener("click", async () => {{
          await navigator.clipboard.writeText(button.dataset.copy || "");
          button.classList.add("copied");
          setTimeout(() => button.classList.remove("copied"), 900);
        }});
      }});
    }}
    searchInput.addEventListener("input", renderSearch);
    clearSearchButton.addEventListener("click", () => {{
      searchInput.value = "";
      renderSearch();
      searchInput.focus();
    }});

    applyTheme();
    setUndoState();
    updateProgress();
  </script>
</body>
</html>
"""
    output_path.write_text(html, encoding="utf-8")


def _render_checklist_items() -> str:
    return "\n".join(f"<li>{escape(item)}</li>" for item in CHECKLIST_ITEMS)


def _search_records_json(search_records: list[SearchRecord]) -> str:
    payload = [
        {
            "title": record.title,
            "text": record.text,
            "contentType": record.content_type,
            "source": record.source,
            "searchText": f"{record.title} {record.text} {record.source}".lower(),
        }
        for record in search_records
        if record.text.strip()
    ]
    return json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")


def _first_sentence_lookup(search_records: list[SearchRecord]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for record in search_records:
        sentence = _first_body_sentence(record)
        if not sentence:
            continue
        lookup.setdefault(record.title, sentence)
        lookup.setdefault(record.source, sentence)
    return lookup


def _first_body_sentence(record: SearchRecord) -> str:
    text = _clean_text(record.text)
    for prefix in (record.source, record.title):
        clean_prefix = _clean_text(prefix)
        if clean_prefix and text.lower().startswith(clean_prefix.lower()):
            text = text[len(clean_prefix) :].strip(" :-")
    if not text:
        return ""
    match = re.search(r"^(.{1,220}?[.!?])(?:\s|$)", text)
    if match:
        return match.group(1)
    fallback = text[:220].strip()
    if len(text) > 220 and " " in fallback:
        fallback = fallback.rsplit(" ", 1)[0].rstrip() + "..."
    return fallback


def _clean_text(value: str) -> str:
    return " ".join(value.split())


def _group_findings(findings: list[Finding]) -> list[tuple[str, str, list[Finding]]]:
    groups: dict[tuple[str, str], list[Finding]] = defaultdict(list)
    for finding in findings:
        location_url = _location_href(finding.location, finding.location_url)
        groups[(finding.location, location_url)].append(finding)

    grouped = [(location, location_url, values) for (location, location_url), values in groups.items()]
    return sorted(grouped, key=lambda group: _natural_sort_key(group[0]))


def _render_page_record(index: int, location: str, findings: list[Finding], first_sentence: str = "") -> str:
    sorted_findings = sorted(findings, key=_finding_sort_key)
    highest = _highest_severity(sorted_findings)
    source_labels = ", ".join(sorted({finding.source for finding in sorted_findings}))
    content_types = ", ".join(sorted({finding.content_type for finding in sorted_findings}))
    bullets = "\n".join(_render_finding_bullet(finding, occurrence) for occurrence, finding in enumerate(sorted_findings))
    sentence_html = f'<p class="page-first-sentence"><strong>First sentence:</strong> {escape(first_sentence)}</p>' if first_sentence else ""

    return f"""<tr class="finding {escape(highest.value)}" data-page="{escape(location)}" data-order="{index}">
  <td>
    <strong class="page-title">{escape(location)}</strong>
    {_copy_button(location, "Copy page name")}
    <div class="meta">
      <span class="pill">Record {index}</span>
      <span class="pill">{len(sorted_findings)} issue(s)</span>
      <span class="pill">Highest: {escape(highest.value)}</span>
      <span class="pill">{escape(source_labels)}</span>
      <span class="pill">{escape(content_types)}</span>
    </div>
    {sentence_html}
    <div class="page-actions">
      <button type="button" class="page-done-button" aria-pressed="false">Mark entire page fixed</button>
    </div>
  </td>
  <td>{bullets}</td>
</tr>"""


def _render_finding_bullet(finding: Finding, occurrence: int = 0) -> str:
    fix = ""
    if finding.suggested_fix:
        fix = f"<details><summary>Copy/paste fix</summary><pre><code>{escape(finding.suggested_fix)}</code></pre></details>"
    item_id = _finding_id(finding, occurrence)
    summary = _issue_summary(finding)

    return f"""<div class="issue-item" data-id="{escape(item_id)}" data-severity="{escape(finding.severity.value)}" data-issue="{escape(finding.issue)}">
      <div class="issue-header">
        <button type="button" class="done-button" aria-label="Mark fixed" aria-pressed="false"></button>
        <strong>{escape(finding.issue)}</strong>
        <button type="button" class="similar-done-button">Clear all similar flags on this page</button>
      </div>
      <div class="meta">
        <span class="pill">{escape(finding.severity.value)}</span>
        <span class="pill">{escape(finding.confidence.value)}</span>
        <span class="pill">{escape(finding.source)}</span>
      </div>
      <p><strong>Summary:</strong> {escape(summary)}</p>
      <p><strong>Evidence:</strong></p>
      <pre><code>{escape(finding.evidence)}</code></pre>
      {_copy_button(finding.evidence, "Copy evidence")}
      {fix}
    </div>"""


def _issue_summary(finding: Finding) -> str:
    if finding.wcag == "Course maintenance":
        return f"{finding.recommendation} This is a course storage and maintenance check, not a WCAG violation."
    reason = _wcag_reason(finding)
    return f"{finding.recommendation} WCAG concern: {reason}"


def _wcag_reason(finding: Finding) -> str:
    if "1.1.1" in finding.wcag:
        return "non-text content needs a text alternative so screen reader users receive the same information."
    if "1.3.1" in finding.wcag:
        return "structure and relationships need to be available programmatically, not just visually."
    if "2.4.2" in finding.wcag:
        return "page titles help users identify where they are."
    if "2.4.4" in finding.wcag or "2.4.9" in finding.wcag:
        return "link purpose should be understandable from the link text or context."
    if "3.2.5" in finding.wcag:
        return "opening behavior should be predictable and intentional."
    if "2.4.6" in finding.wcag:
        return "headings and labels should describe topic or purpose."
    return "the issue may create barriers for users of assistive technology or keyboard/screen reader workflows."


def _copy_button(text: str, label: str) -> str:
    return f'<button type="button" class="copy-button" data-copy="{escape(text, quote=True)}" aria-label="{escape(label)}" title="{escape(label)}"></button>'


def _finding_id(finding: Finding, occurrence: int = 0) -> str:
    raw = "|".join((finding.location, finding.location_url, finding.issue, finding.evidence, str(occurrence)))
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


def _highest_severity(findings: list[Finding]):
    priority = {
        "Critical": 0,
        "High": 1,
        "Medium": 2,
        "Low": 3,
    }
    return min((finding.severity for finding in findings), key=lambda severity: priority[severity.value])


def _natural_sort_key(value: str) -> list[tuple[int, int | str]]:
    parts = re.split(r"(\d+)", value.lower())
    return [(0, int(part)) if part.isdigit() else (1, part) for part in parts if part]


def _finding_sort_key(finding: Finding) -> tuple[int, str, str]:
    if finding.issue == XML_FIGURE_PATTERN_ISSUE:
        priority = 0
    elif finding.issue == BOOTSTRAP_TEMPLATE_ISSUE:
        priority = 1
    else:
        priority = 2
    return (priority, finding.issue.lower(), finding.severity.value)


def _location_href(location: str, location_url: str) -> str:
    if location_url:
        return location_url
    if location.startswith(("http://", "https://")):
        return location
    return ""



